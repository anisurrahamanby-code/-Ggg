# PROGRESS — Mission explainer (English, 9:16)

## 1. Topic / length / ratio
- Topic: "What is the real difference between a human and a dog?" → Maslow's ladder (3 levels as the voice frames it: physical, status, mission) → a Muslim's mission (hadith: ongoing charity, beneficial knowledge, righteous child) → define your own mission.
- Audio: public/audio/voiceover.wav, 142.96 s (mono 44.1 kHz, -15 LUFS). Video = audio + 1 s hold = 143.96 s = 4319 frames @30fps.
- Ratio: 9:16, 1080×1920 (user said 9:16). Config in src/config.ts.

## 2. Decisions
- Skills: diagram-explainer-style (main: flat 2D icon-style art, whole-object motion, word-synced captions) + documentary-collage-explainer (off-white editorial paper, kinetic text, real photo of Maslow, quote card). Project instructions win on conflicts (Windows-safe delivery, user SFX only).
- Profile: theme = psychology/self-improvement on off-white graph paper + religious elements (arch frame, soft gold) in the hadith part | era modern | tone informative → inspirational | structure Q&A + 3-step ladder (tab bar 1·Physical / 2·Status / 3·Mission) | English | medium (2:24) | general adults | fast speech ~178 wpm | assets: 1 real photo, user fonts, user SFX, no music.
- Colour (user's answer): "Off-white graph grids background + all colors mix" → paper #F5F1E8 with graph grid (40px fine + 200px bold lines), multi-colour accents: navy #1B2A4A, yellow highlight #FCD34D, amber #E07A1F (Level 1 physical), indigo #4F46E5 (Level 2 status), teal #0F9D8A (Level 3 mission) + gold #E9B949, crimson #C81E1E (bad/✕), green #16A34A (good/✓), pink #DB2777, sky #0EA5E9, purple #7C3AED.
- Fonts (user ZIP, Latin-capable): Anek Bangla Condensed ExtraBold (display), Hind Siliguri SemiBold/Bold (sans, captions), Tiro Bangla Regular/Italic (serif: quotes, hadith).
- Motion mood: medium-energy (default springs + pop on dog/human gags, slam on reveals); soft & slower in the hadith/death part (respectful). Reason: motivational explainer with a religious core.
- Prophet ﷺ is never drawn; shown only as a text chip. No real logos/brands.
- SFX: only from user ZIP (renamed ASCII in public/sfx): whoosh1-3, pop, bubble_pop, riser, impact_boom, suspense_boom, thud, correct, ding, ting, sparkle, wrong, paper, paper_slide, page_flip, shutter, camera_flash, marker, typing, light_switch, flashback, click, scratch, item. Excluded: sirens, laser, game, glitch, slap, censor beep, notification. No music in ZIP → voice + SFX only.

## 3. SRT corrections
- ASR (faster-whisper) could not download its model (network blocked) → word times = SRT cue limits + silence-detect phrase mapping + syllable-weighted split (approximate, tools/timing.py).
- SRT text checked: no wrong words found → 0 corrections (corrected.srt = original). See corrections.json.
- Note (content, not SRT): Maslow's original hierarchy has five levels; the voice frames it as three. Video follows the voice.

## 4. Scene board (abs. seconds)
| # | time | stage | key cues |
|---|---|---|---|
| A | 0–10.9 | dog icon on ground; 4 activity badges (eats/sleeps/guards/mate) with dog pose swaps; person enters, ✓ ticks + "="; then big "?" REAL DIFFERENCE | eats .70, sleeps .99, territory 1.99, mate 4.15, same 5.97, real 8.18 |
| B | 10.9–15.3 | ladder rises (3 coloured rungs), human/dog at foot; "THE LADDER / OF HUMAN NEEDS" | ladder 12.02, human 14.29 |
| C | 15.3–23.0 | 1943 chip, REAL PHOTO Maslow polaroid, name plate, "HIERARCHY OF NEEDS", arrow to small ladder | 1943 15.74, psychologist 16.83, Abraham 17.48, hierarchy 20.50, ladder 22.42 |
| D | 23.0–33.1 | ladder + 3 level labels; person at bottom, locks on upper rungs, upper dim | three 24.38, physical 25.44, status 26.50, mission 27.89, until 29.43, can't 31.21 |
| E | 33.1–47.2 | Level 1: slumped person, empty plate, "2 DAYS", Nobel thought bubble → ✕; hunger/thirst/sleep tiles fill ✓; muted ghost needs | two 37.76, Nobel 40.09, Not 40.92, hunger 42.19, satisfied 44.28, silent 46.58 |
| F | 47.2–53.2 | dog joins on amber Level-1 platform, "=", NO DIFFERENCE stamp | dog 47.65, no difference 50.80 |
| G | 53.2–62.85 | person climbs to rung 2; title/fame/power/respect cards | reach 54.98, status 56.22, title 59.85, fame 60.32, power 61.17, respect 62.20 |
| H | 62.85–72.7 | dog marks territory (scent waves, dashed boundary), pack of 3 dogs, crown LEADER; then human-crown = dog-crown, NO DIFFERENCE | territory 65.02, scent 65.99, leader 67.19, doesn't 70.28 |
| I | 72.7–77.3 | ladder: "?" then rung 3 lights, light beam, person climbs, dog sits below; MISSION slam | real difference 73.63, third 75.75, mission 76.60 |
| J | 77.3–85.6 | walking person leaves glowing footprints, tree grows; cards: not from body / no pay / awake at night (night window, lamp) | leave 78.06, body 80.76, pays 82.39, awake 84.62 |
| K | 85.6–92.2 | arch frame; "MISSION OF A TRUE MUSLIM"; life timeline → end-of-life line, gold reward dots continue past it | Muslim 87.72, rewards 90.16, death 91.76 |
| L | 92.2–103.1 | Prophet chip (text only); serif quote card word-reveal; row of deed lamps go out except 3; 3 cards: ongoing charity (well), beneficial knowledge (book), righteous child (child, dua); source Sahih Muslim 1631 | said 94.40, end 97.98, except 98.22, charity 99.18, knowledge 100.58, child 102.34 |
| M | 103.1–111.7 | MANY FORMS; imam + prayer mats filling + habit streak; teacher + board + students → graduates | imam 106.09, habit 107.32, teacher 109.33, generation 110.46 |
| N | 111.7–117.1 | person with laptop: writing page + video card; rings reach people icons; 3 mini badges + MISSION ✓ stamp | writing 112.68, videos 113.27, call 113.85, missions 116.53 |
| O | 117.1–126.8 | DEFINE YOUR OWN MISSION; Venn KNOW / GOOD AT / LOVE converge → YOUR MISSION star; "call people toward Allah" chip | know 119.93, good 120.78, love 122.07, together 123.71, call 125.47 |
| P | 126.8–130.8 | community houses ring light up → globe | community 129.02, world 130.20 |
| Q | 130.8–138.3 | callback: ladder, dog + human together on rung 1 then rung 2, "=" + NO DIFFERENCE | back 131.38, physical 134.28, status 135.17, no 136.03 |
| R | 138.3–143.96 | human climbs to glowing rung 3, dog stays; MISSION + BELONGS ONLY TO HUMANS; end hold | mission 140.09, only 141.75, humans 142.37 |

## 5. Status
- [x] Files checked, timing, data (src/data/words.ts, captions.ts)
- [x] Core components (theme, bg, caption, tab bar, art kit)
- [x] Scenes A–Q all written (Q = callback + final, 130.8 s → end) — src/scenes/
- [x] SFX list (src/sfxCues.ts)
- [x] Typecheck clean; first still-frame review done, layout fixes applied
- [x] Full contact sheet check (every 2 s) + fixes; test render of 5 s segment OK; thumbnail OK
- [x] Delivery ZIP mission_explainer_v1.zip

## 6. Current step / next
- Workflow step 8 (waiting for "রেন্ডার করো"). Full render not done here. Next: render only if the user asks; otherwise apply requested changes → v2 ZIP.

## 7. Skill
- diagram-explainer-style (+ documentary-collage-explainer)
