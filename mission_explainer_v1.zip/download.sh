#!/usr/bin/env bash
# Serves the out/ folder on port 8080 (Codespaces: open the forwarded port to download video.mp4)
cd out
echo "Open http://localhost:8080"
if command -v python3 >/dev/null; then python3 -m http.server 8080; else npx http-server -p 8080; fi
