#!/usr/bin/env bash
set -e
npm install
if [ "$(uname)" = "Linux" ]; then bash setup-linux.sh; fi
npm run render
npm run thumb
