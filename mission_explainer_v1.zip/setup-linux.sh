#!/usr/bin/env bash
# Only needed on Linux / GitHub Codespaces (Windows & Mac: skip this).
set -e
sudo apt-get update -y || true
sudo apt-get install -y libnss3 libdbus-1-3 libatk1.0-0 libgbm-dev libxrandr2 libxkbcommon-dev libxfixes3 libxcomposite1 libxdamage1 libpango-1.0-0 libcairo2 libcups2 libatk-bridge2.0-0 || true
sudo apt-get install -y libasound2t64 || sudo apt-get install -y libasound2 || true
npx remotion browser ensure
