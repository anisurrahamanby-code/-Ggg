import React from "react";
import { Composition, Still } from "remotion";
import { Main } from "./Video";
import { Thumbnail } from "./Thumbnail";
import { DURATION, FPS, L } from "./config";

export const RemotionRoot: React.FC = () => (
  <>
    <Composition id="Main" component={Main} durationInFrames={DURATION} fps={FPS} width={L.w} height={L.h} />
    <Still id="Thumbnail" component={Thumbnail} width={L.w} height={L.h} />
  </>
);
