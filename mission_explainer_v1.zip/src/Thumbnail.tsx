import React from "react";
import { AbsoluteFill } from "remotion";
import { useFonts } from "./fonts";
import { Background } from "./components/Base";
import { StartCtx } from "./anim";
import { SceneQ } from "./scenes/SceneOPQ";

// Cover image: the final "MISSION" moment frozen (frame ~4290)
export const Thumbnail: React.FC = () => {
  useFonts();
  return (
    <AbsoluteFill>
      <Background />
      <StartCtx.Provider value={4290}>
        <SceneQ />
      </StartCtx.Provider>
    </AbsoluteFill>
  );
};
