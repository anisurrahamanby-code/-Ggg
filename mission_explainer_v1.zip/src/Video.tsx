import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile } from "remotion";
import { useFonts } from "./fonts";
import { Background, Caption, SceneShell, TabBar } from "./components/Base";
import { SCENES } from "./scenes";
import { SfxTrack } from "./sfx";
import { SFX_CUES } from "./sfxCues";

const OVERLAP = 12;
export const Main: React.FC = () => {
  useFonts();
  return (
    <AbsoluteFill>
      <Background />
      {SCENES.map((s, i) => (
        <Sequence key={i} from={s.start} durationInFrames={s.end - s.start + OVERLAP} name={s.name}>
          <SceneShell start={s.start} end={s.end} enter={s.enter} noExit={s.noExit}>
            <s.C />
          </SceneShell>
        </Sequence>
      ))}
      <TabBar />
      <Caption />
      <SfxTrack cues={SFX_CUES} />
      <Audio src={staticFile("audio/voiceover.wav")} volume={1} />
    </AbsoluteFill>
  );
};
