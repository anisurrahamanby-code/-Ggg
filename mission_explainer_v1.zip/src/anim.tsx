import React, { createContext, useContext } from "react";
import { Easing, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";

export const SPRING = {
  pop: { damping: 11, stiffness: 170, mass: 0.8 },
  soft: { damping: 20, stiffness: 120, mass: 1.0 },
  snap: { damping: 14, stiffness: 260, mass: 0.6 },
  slam: { damping: 9, stiffness: 260, mass: 0.8 },
};
export type SpringKey = keyof typeof SPRING;
export const SMOOTH = Easing.bezier(0.22, 1, 0.36, 1);
export const INOUT = Easing.bezier(0.65, 0, 0.35, 1);

export const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
export const rnd = (seed: number) => {
  const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

// Absolute frame inside scenes (Sequence resets frame; scenes add their start)
export const StartCtx = createContext(0);
export const useF = () => useCurrentFrame() + useContext(StartCtx);

export const sp = (f: number, at: number, k: SpringKey = "pop", fps = 30) =>
  f < at ? 0 : spring({ frame: f - at, fps, config: SPRING[k] });

export const lin = (f: number, a: number, b: number, ease = SMOOTH) =>
  interpolate(f, [a, b], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: ease });

// visibility helper: in at `at`, out at `out` (fast exit 8 frames)
export const vis = (f: number, at: number, out?: number, outDur = 8) => {
  const o = out === undefined ? 1 : 1 - lin(f, out, out + outDur);
  return o;
};

// SVG pop-in wrapper; children drawn around local origin (bottom-centre for art)
export const Pop: React.FC<{
  at: number; out?: number; x?: number; y?: number; s?: number; dy?: number; k?: SpringKey; from?: number;
  rot?: number; children?: React.ReactNode; blur?: boolean;
}> = ({ at, out, x = 0, y = 0, s = 1, dy = 60, k = "pop", from = 0.85, rot = 0, children }) => {
  const f = useF();
  const p = sp(f, at, k);
  const o = clamp01(p * 3) * vis(f, at, out);
  const outP = out === undefined ? 0 : lin(f, out, out + 8);
  if (o <= 0.001) return null;
  const sc = s * (from + (1 - from) * p) * (1 - 0.08 * outP);
  return (
    <g opacity={o} transform={`translate(${x} ${y + (1 - p) * dy + outP * 20}) rotate(${rot}) scale(${sc})`}>{children}</g>
  );
};

// Idle bob for living things
export const Idle: React.FC<{ amp?: number; speed?: number; phase?: number; children?: React.ReactNode }> = ({ amp = 3, speed = 2, phase = 0, children }) => {
  const t = useF() / 30;
  return <g transform={`translate(0 ${Math.sin(t * speed + phase) * amp})`}>{children}</g>;
};

// Move a whole object between points (with walking bob while moving)
export const Mover: React.FC<{ from: [number, number]; to: [number, number]; start: number; dur: number; bob?: number; tilt?: number; children?: React.ReactNode; ease?: (x: number) => number }> =
  ({ from, to, start, dur, bob = 0, tilt = 0, children, ease = INOUT }) => {
    const f = useF();
    const p = lin(f, start, start + dur, ease);
    const moving = p > 0 && p < 1 ? 1 : 0;
    const t = f / 30;
    const x = from[0] + (to[0] - from[0]) * p;
    const y = from[1] + (to[1] - from[1]) * p - Math.abs(Math.sin(t * 9)) * bob * moving;
    return <g transform={`translate(${x} ${y}) rotate(${Math.sin(t * 9) * tilt * moving})`}>{children}</g>;
  };

// Pulsing ring
export const Ring: React.FC<{ x: number; y: number; r?: number; color: string; start: number; period?: number; width?: number }> = ({ x, y, r = 60, color, start, period = 36, width = 5 }) => {
  const f = useF();
  if (f < start) return null;
  const p = ((f - start) % period) / period;
  return <circle cx={x} cy={y} r={r * (1 + 1.2 * p)} fill="none" stroke={color} strokeWidth={width} opacity={0.6 * (1 - p)} />;
};

// HTML absolute box centred on x, top at y
export const Abs: React.FC<{ x: number; y: number; w?: number; children?: React.ReactNode; style?: React.CSSProperties; anchor?: "top" | "center" }> = ({ x, y, w, children, style, anchor = "top" }) => (
  <div style={{ position: "absolute", left: x, top: y, width: w, transform: `translate(-50%, ${anchor === "center" ? "-50%" : "0"})`, ...style }}>{children}</div>
);

// HTML pop wrapper
export const HPop: React.FC<{ at: number; out?: number; k?: SpringKey; dy?: number; from?: number; rot?: number; children?: React.ReactNode; style?: React.CSSProperties; blurIn?: boolean }> =
  ({ at, out, k = "pop", dy = 40, from = 0.9, rot = 0, children, style, blurIn = true }) => {
    const f = useF();
    const p = sp(f, at, k);
    const o = clamp01(p * 3) * vis(f, at, out);
    const outP = out === undefined ? 0 : lin(f, out, out + 8);
    if (o <= 0.001) return null;
    return (
      <div style={{
        opacity: o,
        transform: `translateY(${(1 - p) * dy + outP * 20}px) scale(${(from + (1 - from) * p) * (1 - 0.06 * outP)}) rotate(${rot}deg)`,
        filter: blurIn && p < 0.6 ? `blur(${(1 - p / 0.6) * 8}px)` : undefined,
        ...style,
      }}>{children}</div>
    );
  };
