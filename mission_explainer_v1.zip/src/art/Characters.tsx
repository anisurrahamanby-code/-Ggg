import React from "react";
import { T } from "../theme";
import { useF } from "../anim";

const S = (w = 5) => ({ stroke: T.line, strokeWidth: w, strokeLinejoin: "round" as const, strokeLinecap: "round" as const });

// Thick limb with outline (static pose shapes, no rig)
const Limb: React.FC<{ d: string; color: string; w?: number }> = ({ d, color, w = 15 }) => (
  <>
    <path d={d} stroke={T.line} strokeWidth={w + 9} strokeLinecap="round" strokeLinejoin="round" fill="none" />
    <path d={d} stroke={color} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" fill="none" />
  </>
);

// ── DOG (side view, facing right). origin = ground contact, bottom centre. ~330 wide x 260 tall ──
export type DogPose = "stand" | "eat" | "sleep" | "sit" | "sniff";
export const Dog: React.FC<{ pose?: DogPose; body?: string; dark?: string; collar?: string; scale?: number; flip?: boolean; dim?: number; wag?: boolean }> =
  ({ pose = "stand", body = T.dog, dark = T.dogDark, collar = T.l3, scale = 1, flip = false, dim = 0, wag = true }) => {
    const f = useF();
    const wagA = wag ? Math.sin(f / 3) * 10 : 0;
    const sx = flip ? -scale : scale;
    const g = (
      <g transform={`scale(${sx} ${scale})`} opacity={1 - dim * 0.55}>
        {pose === "sleep" ? (
          <g>
            <ellipse cx={0} cy={-6} rx={150} ry={10} fill="rgba(27,42,74,0.10)" />
            <path d="M -125 -40 Q -175 -40 -170 -10 Q -150 0 -100 -6" stroke={T.line} strokeWidth={24} fill="none" strokeLinecap="round" />
            <path d="M -125 -40 Q -175 -40 -170 -10 Q -150 0 -100 -6" stroke={body} strokeWidth={15} fill="none" strokeLinecap="round" />
            <rect x={-125} y={-98} width={215} height={92} rx={46} fill={body} {...S()} />
            <rect x={60} y={-26} width={70} height={24} rx={12} fill={body} {...S()} />
            <g transform="translate(118 -62)">
              <circle r={48} fill={body} {...S()} />
              <rect x={14} y={-4} width={66} height={40} rx={20} fill={body} {...S()} />
              <circle cx={78} cy={8} r={9} fill={T.line} />
              <ellipse cx={-26} cy={-6} rx={17} ry={36} fill={dark} {...S(4)} transform="rotate(25 -26 -6)" />
              <path d="M 4 -14 Q 14 -6 24 -14" stroke={T.line} strokeWidth={4} fill="none" strokeLinecap="round" />
            </g>
          </g>
        ) : pose === "sit" ? (
          <g>
            <ellipse cx={0} cy={-6} rx={130} ry={10} fill="rgba(27,42,74,0.10)" />
            <g transform={`rotate(${wagA} -95 -60)`}>
              <path d="M -95 -60 Q -150 -60 -160 -110" stroke={T.line} strokeWidth={24} fill="none" strokeLinecap="round" />
              <path d="M -95 -60 Q -150 -60 -160 -110" stroke={body} strokeWidth={15} fill="none" strokeLinecap="round" />
            </g>
            <rect x={30} y={-140} width={24} height={140} rx={11} fill={dark} {...S()} />
            <path d="M -110 -20 Q -120 -150 -10 -200 Q 70 -225 85 -150 Q 90 -60 40 -10 Z" fill={body} {...S()} />
            <ellipse cx={-62} cy={-50} rx={58} ry={48} fill={body} {...S()} />
            <rect x={-118} y={-26} width={70} height={26} rx={12} fill={body} {...S()} />
            <rect x={56} y={-140} width={24} height={140} rx={11} fill={body} {...S()} />
            <rect x={52} y={-198} width={18} height={52} rx={6} fill={collar} {...S(4)} transform="rotate(-20 61 -172)" />
            <g transform="translate(78 -240)">
              <circle r={50} fill={body} {...S()} />
              <rect x={18} y={-6} width={70} height={42} rx={20} fill={body} {...S()} />
              <circle cx={86} cy={6} r={10} fill={T.line} />
              <circle cx={14} cy={-14} r={6.5} fill={T.line} />
              <ellipse cx={-22} cy={-4} rx={18} ry={38} fill={dark} {...S(4)} transform="rotate(15 -22 -4)" />
              <path d="M 52 28 Q 62 34 72 28" stroke={T.line} strokeWidth={4} fill="none" strokeLinecap="round" />
            </g>
          </g>
        ) : (
          <g>
            <ellipse cx={0} cy={-6} rx={140} ry={10} fill="rgba(27,42,74,0.10)" />
            {/* far legs */}
            <rect x={-70} y={-86} width={22} height={86} rx={10} fill={dark} {...S()} />
            <rect x={66} y={-86} width={22} height={86} rx={10} fill={dark} {...S()} />
            {/* tail */}
            <g transform={`rotate(${wagA} -112 -140)`}>
              <path d="M -112 -140 Q -160 -165 -152 -215" stroke={T.line} strokeWidth={24} fill="none" strokeLinecap="round" />
              <path d="M -112 -140 Q -160 -165 -152 -215" stroke={body} strokeWidth={15} fill="none" strokeLinecap="round" />
            </g>
            <rect x={-122} y={-170} width={215} height={96} rx={46} fill={body} {...S()} />
            {/* near legs */}
            <rect x={-100} y={-90} width={24} height={90} rx={11} fill={body} {...S()} />
            <rect x={36} y={-90} width={24} height={90} rx={11} fill={body} {...S()} />
            <path d="M -60 -150 Q -20 -160 20 -150" stroke={dark} strokeWidth={6} fill="none" strokeLinecap="round" opacity={0.6} />
            {/* head group, rotates around neck for eat/sniff */}
            <g transform={`rotate(${pose === "eat" ? 42 : pose === "sniff" ? 18 : 0} 72 -150)`}>
              <rect x={60} y={-185} width={18} height={54} rx={6} fill={collar} {...S(4)} transform="rotate(-25 69 -158)" />
              <g transform="translate(102 -196)">
                <circle r={50} fill={body} {...S()} />
                <rect x={18} y={-6} width={70} height={42} rx={20} fill={body} {...S()} />
                <circle cx={86} cy={6} r={10} fill={T.line} />
                <circle cx={14} cy={-14} r={6.5} fill={T.line} />
                <circle cx={16} cy={-16} r={2} fill={T.white} />
                <ellipse cx={-22} cy={-4} rx={18} ry={38} fill={dark} {...S(4)} transform="rotate(15 -22 -4)" />
                <path d="M 52 28 Q 62 34 72 28" stroke={T.line} strokeWidth={4} fill="none" strokeLinecap="round" />
              </g>
            </g>
          </g>
        )}
      </g>
    );
    return g;
  };

// ── PERSON icon. origin = feet, bottom centre. height ≈ 215 x scale ──
export type Pose = "stand" | "point" | "hold" | "slump" | "raise" | "dua" | "walk";
export const Person: React.FC<{
  pose?: Pose; scale?: number; skin?: string; cloth?: string; pants?: string; hair?: string;
  cap?: boolean; flip?: boolean; dim?: number; mood?: "smile" | "sad" | "open" | "calm"; holdColor?: string; tie?: string; glow?: string;
}> = ({ pose = "stand", scale = 1, skin = T.skin, cloth = T.l3, pants = T.navy, hair = T.hair, cap = false, flip = false, dim = 0, mood = "smile", holdColor = T.navy, tie, glow }) => {
  const sx = flip ? -scale : scale;
  const headTilt = pose === "slump" ? 14 : 0;
  return (
    <g transform={`scale(${sx} ${scale})`} opacity={1 - dim * 0.55}>
      {glow && <ellipse cx={0} cy={-110} rx={110} ry={150} fill={glow} opacity={0.22} />}
      <ellipse cx={0} cy={-4} rx={62} ry={8} fill="rgba(27,42,74,0.12)" />
      {/* legs */}
      {pose === "walk" ? (
        <>
          <Limb d="M -8 -70 L -26 -8" color={pants} w={17} />
          <Limb d="M 8 -70 L 24 -8" color={pants} w={17} />
        </>
      ) : (
        <>
          <rect x={-24} y={-74} width={20} height={74} rx={9} fill={pants} {...S(4)} />
          <rect x={4} y={-74} width={20} height={74} rx={9} fill={pants} {...S(4)} />
        </>
      )}
      {/* back arms (behind torso) */}
      {pose === "stand" && <><Limb d="M -30 -132 L -38 -76" color={skin} /><Limb d="M 30 -132 L 38 -76" color={skin} /></>}
      {pose === "walk" && <><Limb d="M -30 -132 L -46 -82" color={skin} /><Limb d="M 30 -132 L 44 -84" color={skin} /></>}
      {pose === "slump" && <><Limb d="M -28 -126 L -30 -70" color={skin} /><Limb d="M 28 -126 L 30 -70" color={skin} /></>}
      {pose === "point" && <><Limb d="M -30 -132 L -38 -76" color={skin} /><Limb d="M 30 -132 L 98 -160" color={skin} /></>}
      {pose === "raise" && <><Limb d="M -30 -134 L -66 -206" color={skin} /><Limb d="M 30 -134 L 66 -206" color={skin} /></>}
      {pose === "hold" && <><Limb d="M -30 -128 L 2 -100" color={skin} /><Limb d="M 30 -128 L 14 -100" color={skin} /></>}
      {/* torso */}
      <rect x={-34} y={-146} width={68} height={82} rx={26} fill={cloth} {...S(4)} />
      {tie && <path d="M 0 -140 L -7 -112 L 0 -96 L 7 -112 Z" fill={tie} />}
      {pose === "hold" && <rect x={-16} y={-128} width={40} height={30} rx={5} fill={holdColor} {...S(3)} />}
      {pose === "dua" && (
        <>
          <Limb d="M -30 -130 L -24 -104 L -36 -146" color={skin} w={14} />
          <Limb d="M 30 -130 L 24 -104 L 36 -146" color={skin} w={14} />
        </>
      )}
      {/* head */}
      <g transform={`rotate(${headTilt} 0 -146)`}>
        <circle cx={0} cy={-178} r={31} fill={skin} {...S(4)} />
        {cap ? (
          <path d="M -30 -186 Q -30 -214 0 -215 Q 30 -214 30 -186 Z" fill={T.white} {...S(4)} />
        ) : (
          <path d="M -31 -182 Q -30 -215 0 -215 Q 30 -215 31 -182 Q 14 -198 -31 -182 Z" fill={hair} />
        )}
        <circle cx={-10} cy={-176} r={3.6} fill={T.line} />
        <circle cx={10} cy={-176} r={3.6} fill={T.line} />
        {mood === "smile" && <path d="M -9 -163 Q 0 -155 9 -163" stroke={T.line} strokeWidth={3.5} fill="none" strokeLinecap="round" />}
        {mood === "sad" && <path d="M -9 -157 Q 0 -165 9 -157" stroke={T.line} strokeWidth={3.5} fill="none" strokeLinecap="round" />}
        {mood === "open" && <ellipse cx={0} cy={-160} rx={6} ry={7} fill={T.line} />}
        {mood === "calm" && <path d="M -7 -161 L 7 -161" stroke={T.line} strokeWidth={3.5} strokeLinecap="round" />}
      </g>
    </g>
  );
};
