import React from "react";
import { T, FONT } from "../theme";
import { lin, sp, useF, clamp01, INOUT } from "../anim";

export const LEVEL_COLORS = [T.l1, T.l2, T.l3];
export const LEVEL_NAMES = ["Physical", "Status", "Mission"];
// rung top-surface y for level i (0..2) of a ladder with given ground & height
export const rungY = (ground: number, h: number, i: number) => ground - h * [0.22, 0.52, 0.82][i];

// Ladder: two wooden rails + 3 coloured level rungs. origin = ground centre.
export const Ladder: React.FC<{
  x: number; ground: number; h?: number; w?: number; at: number;
  rungAt?: number[]; lit?: number[]; locked?: number[]; lockAt?: number; dimUpper?: number; glow3?: number; numbers?: boolean; scale?: number;
}> = ({ x, ground, h = 760, w = 300, at, rungAt, lit = [], locked = [], lockAt = 0, dimUpper = 0, glow3 = 0, numbers = true, scale = 1 }) => {
  const f = useF();
  const p = lin(f, at, at + 22, INOUT);
  const rails = [-w / 2, w / 2];
  const ra = rungAt ?? [at + 10, at + 16, at + 22];
  const top = ground - h;
  return (
    <g transform={`translate(${x} ${ground}) scale(${scale}) translate(${-x} ${-ground})`}>
      {/* glow behind top rung */}
      {glow3 > 0 && (
        <g opacity={glow3}>
          <defs>
            <radialGradient id="g3" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor={T.gold} stopOpacity={0.75} />
              <stop offset="100%" stopColor={T.gold} stopOpacity={0} />
            </radialGradient>
          </defs>
          <ellipse cx={x} cy={rungY(ground, h, 2)} rx={w * 1.3} ry={170} fill="url(#g3)" />
        </g>
      )}
      {rails.map((dx, i) => (
        <g key={i}>
          <line x1={x + dx} y1={ground} x2={x + dx} y2={ground - (ground - top + 30) * p} stroke={T.line} strokeWidth={30} strokeLinecap="round" />
          <line x1={x + dx} y1={ground} x2={x + dx} y2={ground - (ground - top + 30) * p} stroke={T.wood} strokeWidth={20} strokeLinecap="round" />
        </g>
      ))}
      {/* plain rungs between levels */}
      {[0.07, 0.37, 0.67, 0.97].map((k, i) => {
        const y = ground - h * k;
        const o = clamp01((ground - y) / (h * p + 1) < 1 ? 1 : 0) * (p > k ? 1 : 0);
        return <rect key={i} x={x - w / 2} y={y - 7} width={w} height={14} rx={7} fill={T.wood} stroke={T.line} strokeWidth={4} opacity={o} />;
      })}
      {[0, 1, 2].map((i) => {
        const y = rungY(ground, h, i);
        const s = sp(f, ra[i], "pop");
        if (s <= 0.01) return null;
        const isLit = lit.includes(i);
        const isDim = i > 0 && dimUpper > 0 ? dimUpper : 0;
        const lk = locked.includes(i) ? sp(f, lockAt + i * 5, "snap") : 0;
        return (
          <g key={i} transform={`translate(${x} ${y + 18}) scale(${0.6 + 0.4 * s}) translate(${-x} ${-(y + 18)})`} opacity={clamp01(s * 2) * (1 - isDim * 0.55)}>
            {isLit && <rect x={x - w / 2 - 30} y={y - 16} width={w + 60} height={68} rx={34} fill={LEVEL_COLORS[i]} opacity={0.22} />}
            <rect x={x - w / 2 - 22} y={y} width={w + 44} height={36} rx={18} fill={LEVEL_COLORS[i]} stroke={T.line} strokeWidth={5} />
            <rect x={x - w / 2 - 8} y={y + 6} width={w * 0.5} height={8} rx={4} fill="rgba(255,255,255,0.45)" />
            {numbers && (
              <g transform={`translate(${x - w / 2 - 50} ${y + 18})`}>
                <circle r={30} fill={T.card} stroke={LEVEL_COLORS[i]} strokeWidth={6} />
                <text y={12} textAnchor="middle" fontFamily={FONT.display} fontSize={36} fill={T.navy}>{i + 1}</text>
              </g>
            )}
            {lk > 0.01 && (
              <g transform={`translate(${x + w / 2 + 56} ${y + 14}) scale(${lk})`}>
                <Lock />
              </g>
            )}
          </g>
        );
      })}
    </g>
  );
};

export const Lock: React.FC<{ color?: string; s?: number }> = ({ color = T.bad, s = 1 }) => (
  <g transform={`scale(${s})`}>
    <path d="M -18 -8 L -18 -26 Q -18 -46 0 -46 Q 18 -46 18 -26 L 18 -8" fill="none" stroke={T.line} strokeWidth={14} strokeLinecap="round" />
    <path d="M -18 -8 L -18 -26 Q -18 -46 0 -46 Q 18 -46 18 -26 L 18 -8" fill="none" stroke="#C9CDD6" strokeWidth={7} strokeLinecap="round" />
    <rect x={-30} y={-12} width={60} height={46} rx={10} fill={color} stroke={T.line} strokeWidth={5} />
    <circle cx={0} cy={8} r={6} fill={T.line} />
  </g>
);
