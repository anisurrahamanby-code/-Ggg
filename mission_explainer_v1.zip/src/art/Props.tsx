import React from "react";
import { T, FONT } from "../theme";
import { useF } from "../anim";

const S = (w = 5) => ({ stroke: T.line, strokeWidth: w, strokeLinejoin: "round" as const, strokeLinecap: "round" as const });
type P = { s?: number; c?: string };
const G: React.FC<{ s?: number; children?: React.ReactNode }> = ({ s = 1, children }) => <g transform={`scale(${s})`}>{children}</g>;

// All icons centred on origin, ~120px box at s=1
export const Bowl: React.FC<P & { full?: boolean }> = ({ s, c = T.l1, full = true }) => (
  <G s={s}>
    {full && <><circle cx={-22} cy={-22} r={14} fill={T.dogDark} {...S(3)} /><circle cx={2} cy={-28} r={14} fill="#A86B3A" {...S(3)} /><circle cx={24} cy={-20} r={13} fill={T.dogDark} {...S(3)} /></>}
    <path d="M -58 -18 L 58 -18 L 44 26 L -44 26 Z" fill={c} {...S()} />
    <rect x={-62} y={-24} width={124} height={14} rx={7} fill={c} {...S()} />
  </G>
);
export const Zzz: React.FC<P> = ({ s, c = T.l2 }) => {
  const f = useF();
  return (
    <G s={s}>
      {[0, 1, 2].map((i) => {
        const t = ((f / 30 + i * 0.5) % 1.5) / 1.5;
        return <text key={i} x={i * 26 + t * 10} y={-i * 30 - t * 20} fontFamily={FONT.display} fontSize={34 + i * 10} fill={c} opacity={1 - t * 0.6}>Z</text>;
      })}
    </G>
  );
};
export const Moon: React.FC<P> = ({ s, c = T.gold }) => (
  <G s={s}><path d="M 20 -50 A 52 52 0 1 0 40 30 A 42 42 0 1 1 20 -50 Z" fill={c} {...S()} /></G>
);
export const DogHouse: React.FC<P> = ({ s, c = T.bad }) => (
  <G s={s}>
    <rect x={-90} y={-130} width={180} height={130} fill={T.wood} {...S()} />
    <path d="M -110 -120 L 0 -200 L 110 -120 Z" fill={c} {...S()} />
    <path d="M -36 0 L -36 -58 Q 0 -96 36 -58 L 36 0 Z" fill={T.line} />
  </G>
);
export const Heart: React.FC<P> = ({ s, c = T.pink }) => (
  <G s={s}><path d="M 0 40 C -70 -6 -52 -64 -14 -54 Q 0 -50 0 -32 Q 0 -50 14 -54 C 52 -64 70 -6 0 40 Z" fill={c} {...S()} /></G>
);
export const Plate: React.FC<P & { empty?: boolean }> = ({ s, c = T.white, empty = true }) => (
  <G s={s}>
    <ellipse cx={0} cy={0} rx={72} ry={26} fill={c} {...S()} />
    <ellipse cx={0} cy={-2} rx={46} ry={14} fill="none" stroke="#D6D2C8" strokeWidth={4} />
    {!empty && <ellipse cx={0} cy={-10} rx={34} ry={14} fill={T.l1} {...S(3)} />}
    <path d="M 92 -46 L 92 22 M 84 -46 L 84 -24 M 100 -46 L 100 -24 M 84 -24 Q 92 -14 100 -24" fill="none" {...S(5)} />
  </G>
);
export const Glass: React.FC<P & { fill?: number }> = ({ s, c = T.sky, fill = 0.7 }) => (
  <G s={s}>
    <path d={`M -30 ${56 - 100 * fill} L 30 ${56 - 100 * fill} L 26 56 L -26 56 Z`} fill={c} opacity={0.8} />
    <path d="M -38 -50 L 38 -50 L 28 58 L -28 58 Z" fill="rgba(255,255,255,0.35)" {...S()} />
  </G>
);
export const Bed: React.FC<P> = ({ s, c = T.l2 }) => (
  <G s={s}>
    <rect x={-70} y={-20} width={140} height={34} rx={8} fill={c} {...S()} />
    <rect x={-60} y={-38} width={44} height={22} rx={10} fill={T.white} {...S(4)} />
    <path d="M -76 -50 L -76 40 M 76 -10 L 76 40" {...S(9)} />
  </G>
);
export const Medal: React.FC<P> = ({ s, c = T.gold }) => (
  <G s={s}>
    <path d="M -30 -70 L -10 -10 L 10 -10 L 30 -70 Z" fill={T.bad} {...S(4)} />
    <path d="M -2 -70 L 8 -10" stroke={T.l2} strokeWidth={8} />
    <circle cx={0} cy={22} r={40} fill={c} {...S()} />
    <circle cx={0} cy={22} r={26} fill="none" stroke="rgba(255,255,255,0.6)" strokeWidth={5} />
    <path d="M 0 6 L 6 18 L 19 19 L 9 28 L 12 41 L 0 34 L -12 41 L -9 28 L -19 19 L -6 18 Z" fill="#FFF3C4" />
  </G>
);
export const Crown: React.FC<P> = ({ s, c = T.gold }) => (
  <G s={s}>
    <path d="M -56 30 L -60 -30 L -28 0 L 0 -46 L 28 0 L 60 -30 L 56 30 Z" fill={c} {...S()} />
    <circle cx={0} cy={-50} r={8} fill={T.bad} {...S(3)} />
    <circle cx={-60} cy={-34} r={7} fill={T.sky} {...S(3)} />
    <circle cx={60} cy={-34} r={7} fill={T.sky} {...S(3)} />
    <rect x={-56} y={16} width={112} height={14} fill="rgba(255,255,255,0.35)" />
  </G>
);
export const Star: React.FC<P> = ({ s, c = T.gold }) => (
  <G s={s}><path d="M 0 -60 L 17 -20 L 60 -18 L 26 9 L 38 52 L 0 28 L -38 52 L -26 9 L -60 -18 L -17 -20 Z" fill={c} {...S()} /></G>
);
export const NamePlate: React.FC<P & { text?: string }> = ({ s, c = T.l2, text = "BIG TITLE" }) => (
  <G s={s}>
    <path d="M -86 30 L -70 -24 L 70 -24 L 86 30 Z" fill={c} {...S()} />
    <rect x={-60} y={-14} width={120} height={30} rx={4} fill={T.gold} {...S(3)} />
    <text y={8} textAnchor="middle" fontFamily={FONT.display} fontSize={22} fill={T.navy}>{text}</text>
  </G>
);
export const Trophy: React.FC<P> = ({ s, c = T.gold }) => (
  <G s={s}>
    <path d="M -42 -54 Q -78 -54 -66 -20 Q -56 2 -30 0 M 42 -54 Q 78 -54 66 -20 Q 56 2 30 0" fill="none" {...S(7)} />
    <path d="M -44 -60 L 44 -60 Q 44 10 0 18 Q -44 10 -44 -60 Z" fill={c} {...S()} />
    <rect x={-10} y={16} width={20} height={20} fill={c} {...S(4)} />
    <rect x={-36} y={36} width={72} height={20} rx={4} fill={T.navy} {...S(4)} />
  </G>
);
export const Bolt: React.FC<P> = ({ s, c = T.l1 }) => (
  <G s={s}><path d="M 14 -64 L -36 8 L -4 8 L -16 64 L 38 -12 L 6 -12 Z" fill={c} {...S()} /></G>
);
export const Calendar: React.FC<P & { n?: number }> = ({ s, c = T.bad, n = 2 }) => (
  <G s={s}>
    <rect x={-60} y={-52} width={120} height={110} rx={14} fill={T.white} {...S()} />
    <path d="M -60 -52 L 60 -52 L 60 -18 L -60 -18 Z" fill={c} {...S()} />
    <path d="M -30 -66 L -30 -40 M 30 -66 L 30 -40" {...S(8)} />
    <text y={44} textAnchor="middle" fontFamily={FONT.display} fontSize={62} fill={T.navy}>{n}</text>
  </G>
);
export const Coin: React.FC<P> = ({ s, c = T.gold }) => (
  <G s={s}>
    <circle r={48} fill={c} {...S()} />
    <circle r={34} fill="none" stroke="rgba(255,255,255,0.55)" strokeWidth={5} />
    <path d="M -14 -18 Q 0 -26 14 -18" stroke="rgba(255,255,255,0.8)" strokeWidth={6} fill="none" strokeLinecap="round" />
  </G>
);
export const Eye: React.FC<P> = ({ s, c = T.sky }) => (
  <G s={s}>
    <path d="M -64 0 Q 0 -54 64 0 Q 0 54 -64 0 Z" fill={T.white} {...S()} />
    <circle r={22} fill={c} {...S(4)} />
    <circle r={9} fill={T.line} />
  </G>
);
export const Body: React.FC<P> = ({ s, c = T.l1 }) => (
  <G s={s}>
    <circle cx={0} cy={-46} r={20} fill={c} {...S(4)} />
    <rect x={-28} y={-22} width={56} height={66} rx={20} fill={c} {...S(4)} />
  </G>
);
export const Speaker: React.FC<P & { muted?: boolean }> = ({ s, c = T.muted, muted = true }) => (
  <G s={s}>
    <path d="M -44 -16 L -24 -16 L 4 -40 L 4 40 L -24 16 L -44 16 Z" fill={c} {...S()} />
    {muted ? <path d="M 20 -18 L 52 18 M 52 -18 L 20 18" stroke={T.bad} strokeWidth={9} strokeLinecap="round" /> : <path d="M 20 -18 Q 34 0 20 18" fill="none" {...S(6)} />}
  </G>
);
export const Book: React.FC<P & { glow?: boolean }> = ({ s, c = T.sky, glow }) => {
  const f = useF();
  return (
    <G s={s}>
      {glow && [0, 1, 2, 3, 4].map((i) => {
        const a = -150 + i * 30;
        const r1 = 70, r2 = 104 + Math.sin(f / 8 + i) * 8;
        const rad = (a * Math.PI) / 180;
        return <line key={i} x1={Math.cos(rad) * r1} y1={Math.sin(rad) * r1 - 10} x2={Math.cos(rad) * r2} y2={Math.sin(rad) * r2 - 10} stroke={T.gold} strokeWidth={8} strokeLinecap="round" />;
      })}
      <path d="M 0 -20 Q -36 -40 -74 -30 L -74 44 Q -36 34 0 52 Z" fill={T.white} {...S()} />
      <path d="M 0 -20 Q 36 -40 74 -30 L 74 44 Q 36 34 0 52 Z" fill={T.white} {...S()} />
      <path d="M -60 -12 Q -34 -20 -12 -8 M -60 6 Q -34 -2 -12 10 M 12 -8 Q 34 -20 60 -12 M 12 10 Q 34 -2 60 6" fill="none" stroke={c} strokeWidth={5} strokeLinecap="round" />
      <path d="M 0 -20 L 0 52" {...S(5)} />
    </G>
  );
};
// water well (ongoing charity)
export const Well: React.FC<P> = ({ s, c = T.l3 }) => {
  const f = useF();
  const drop = ((f % 30) / 30);
  return (
    <G s={s}>
      <path d="M -60 -70 L 0 -110 L 60 -70 Z" fill={T.bad} {...S()} />
      <path d="M -46 -70 L -46 10 M 46 -70 L 46 10" {...S(9)} />
      <path d="M -46 -46 L 46 -46" {...S(5)} />
      <path d="M 0 -46 L 0 -14" {...S(3)} />
      <rect x={-12} y={-16} width={24} height={20} rx={3} fill={T.wood} {...S(3)} />
      <path d="M -66 10 L 66 10 L 58 64 L -58 64 Z" fill="#B7B0A2" {...S()} />
      <path d="M -66 30 L 66 30 M -62 48 L 62 48" stroke={T.line} strokeWidth={3} opacity={0.4} />
      <ellipse cx={0} cy={10} rx={58} ry={10} fill={c} {...S(4)} />
      <path d={`M 0 ${6 + drop * 0} q -6 10 0 14 q 6 -4 0 -14`} fill={T.sky} opacity={1 - drop} transform={`translate(30 ${drop * 30 - 30})`} />
    </G>
  );
};
export const House: React.FC<P & { lit?: boolean }> = ({ s, c = T.l1, lit }) => (
  <G s={s}>
    <rect x={-44} y={-60} width={88} height={60} fill={T.card} {...S(4)} />
    <path d="M -56 -54 L 0 -100 L 56 -54 Z" fill={c} {...S(4)} />
    <rect x={-12} y={-30} width={24} height={30} fill={T.line} />
    <rect x={18} y={-46} width={18} height={16} fill={lit ? T.gold : "#D9D3C6"} {...S(3)} />
    <rect x={-36} y={-46} width={18} height={16} fill={lit ? T.gold : "#D9D3C6"} {...S(3)} />
  </G>
);
export const Laptop: React.FC<P & { play?: boolean }> = ({ s, c = T.navy, play = true }) => (
  <G s={s}>
    <rect x={-90} y={-120} width={180} height={116} rx={10} fill={c} {...S()} />
    <rect x={-76} y={-106} width={152} height={88} rx={4} fill={T.sky} />
    {play && <path d="M -14 -82 L 20 -62 L -14 -42 Z" fill={T.white} />}
    <path d="M -116 0 L 116 0 L 100 18 L -100 18 Z" fill="#C9CDD6" {...S()} />
  </G>
);
export const Page: React.FC<P> = ({ s, c = T.l3 }) => (
  <G s={s}>
    <path d="M -50 -64 L 30 -64 L 50 -44 L 50 64 L -50 64 Z" fill={T.white} {...S()} />
    {[-36, -16, 4, 24, 44].map((y, i) => <path key={y} d={`M -34 ${y} L ${i === 4 ? 0 : 34} ${y}`} stroke={c} strokeWidth={6} strokeLinecap="round" />)}
    <g transform="translate(46 30) rotate(35)">
      <rect x={-8} y={-70} width={16} height={70} fill={T.l1} {...S(4)} />
      <path d="M -8 0 L 0 18 L 8 0 Z" fill={T.navy} {...S(3)} />
    </g>
  </G>
);
export const Globe: React.FC<P & { spin?: boolean }> = ({ s, c = T.sky }) => {
  const f = useF();
  const o = (f * 1.2) % 120;
  return (
    <G s={s}>
      <defs><clipPath id="globeclip"><circle r={100} /></clipPath></defs>
      <circle r={100} fill={c} {...S(6)} />
      <g clipPath="url(#globeclip)">
        {[-1, 0, 1].map((k) => (
          <g key={k} transform={`translate(${k * 240 + o - 60} 0)`}>
            <path d="M -60 -70 Q -20 -90 10 -60 Q 30 -30 0 -10 Q -30 10 -50 -20 Z" fill={T.good} opacity={0.9} />
            <path d="M 40 10 Q 80 0 90 40 Q 70 80 40 70 Q 20 40 40 10 Z" fill={T.good} opacity={0.9} />
            <path d="M -40 30 Q -20 30 -20 60 Q -40 80 -60 60 Z" fill={T.good} opacity={0.9} />
          </g>
        ))}
      </g>
      <ellipse rx={100} ry={36} fill="none" stroke="rgba(255,255,255,0.45)" strokeWidth={3} />
      <circle r={100} fill="none" {...S(6)} />
    </G>
  );
};
export const Tree: React.FC<P & { grow?: number }> = ({ s, c = T.good, grow = 1 }) => (
  <G s={s}>
    <g transform={`scale(${0.2 + 0.8 * grow})`}>
      <path d="M -10 0 L -8 -110 L 8 -110 L 10 0 Z" fill={T.wood} {...S(4)} />
      <circle cx={0} cy={-150} r={62 * grow} fill={c} {...S(5)} />
      <circle cx={-50} cy={-118} r={40 * grow} fill={c} {...S(5)} />
      <circle cx={52} cy={-120} r={42 * grow} fill={c} {...S(5)} />
      <circle cx={-14} cy={-170} r={10} fill="rgba(255,255,255,0.35)" />
    </g>
  </G>
);
export const Footprint: React.FC<P> = ({ s, c = T.l3 }) => (
  <G s={s}>
    <ellipse cx={0} cy={0} rx={13} ry={22} fill={c} />
    {[-10, -3, 4, 10].map((x, i) => <circle key={i} cx={x} cy={-28 + Math.abs(x) * 0.3} r={4.5} fill={c} />)}
  </G>
);
export const Lamp: React.FC<P & { on?: number }> = ({ s, c = T.l1, on = 1 }) => (
  <G s={s}>
    {on > 0 && <path d="M -40 -96 L 40 -96 L 110 40 L -110 40 Z" fill={T.gold} opacity={0.28 * on} />}
    <path d="M -40 -96 L 40 -96 L 24 -140 L -24 -140 Z" fill={c} {...S()} />
    <path d="M 0 -96 L 0 30 M -40 34 L 40 34" {...S(8)} />
  </G>
);
export const Mat: React.FC<P> = ({ s, c = T.l3 }) => (
  <G s={s}>
    <path d="M -34 0 L -34 -18 L 34 -18 L 34 0 Z" fill={c} {...S(4)} />
    <path d="M -34 -18 L -34 -26 Q 0 -44 34 -26 L 34 -18" fill={c} {...S(4)} />
    <path d="M -24 -8 L 24 -8" stroke="rgba(255,255,255,0.6)" strokeWidth={3} />
  </G>
);
export const Board: React.FC<P> = ({ s, c = "#1F5F4A" }) => (
  <G s={s}>
    <rect x={-150} y={-210} width={300} height={180} rx={10} fill={c} stroke={T.wood} strokeWidth={14} />
    <path d="M -110 -160 L 40 -160 M -110 -120 L 90 -120 M -110 -80 L 10 -80" stroke="rgba(255,255,255,0.8)" strokeWidth={6} strokeLinecap="round" />
    <path d="M -110 -30 L -130 0 M 110 -30 L 130 0" {...S(8)} />
  </G>
);
export const GradCap: React.FC<P> = ({ s, c = T.navy }) => (
  <G s={s}>
    <path d="M -50 0 L 0 -22 L 50 0 L 0 22 Z" fill={c} {...S(4)} />
    <path d="M -26 10 L -26 28 Q 0 40 26 28 L 26 10" fill={c} {...S(4)} />
    <path d="M 40 4 L 40 30" stroke={T.gold} strokeWidth={5} strokeLinecap="round" />
  </G>
);
export const Check: React.FC<P> = ({ s, c = T.good }) => (
  <G s={s}><circle r={30} fill={c} {...S(4)} /><path d="M -13 1 L -3 12 L 15 -10" stroke={T.white} strokeWidth={8} fill="none" strokeLinecap="round" strokeLinejoin="round" /></G>
);
export const Cross: React.FC<P> = ({ s, c = T.bad }) => (
  <G s={s}><path d="M -40 -40 L 40 40 M 40 -40 L -40 40" stroke={T.line} strokeWidth={30} strokeLinecap="round" /><path d="M -40 -40 L 40 40 M 40 -40 L -40 40" stroke={c} strokeWidth={18} strokeLinecap="round" /></G>
);
export const Post: React.FC<P> = ({ s, c = T.wood }) => (
  <G s={s}>
    <rect x={-18} y={-150} width={36} height={150} rx={6} fill={c} {...S()} />
    <path d="M -18 -150 L 0 -172 L 18 -150 Z" fill={c} {...S()} />
  </G>
);
export const Bubble: React.FC<{ w: number; h: number; tailX?: number; tailY?: number; fill?: string; dashed?: boolean }> = ({ w, h, tailX = -w * 0.3, tailY = h * 0.75, fill = T.card, dashed }) => (
  <g>
    <circle cx={tailX * 0.8} cy={h / 2 + 22} r={14} fill={fill} {...S(4)} strokeDasharray={dashed ? "10 10" : undefined} />
    <circle cx={tailX} cy={tailY} r={8} fill={fill} {...S(4)} />
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={h / 2.4} fill={fill} {...S(5)} strokeDasharray={dashed ? "14 12" : undefined} />
  </g>
);
// Mosque-style pointed arch frame (outline), origin = bottom centre
export const Arch: React.FC<{ w: number; h: number; c?: string; sw?: number; fill?: string; draw?: number }> = ({ w, h, c = T.gold, sw = 8, fill = "none", draw = 1 }) => {
  const d = `M ${-w / 2} 0 L ${-w / 2} ${-h + w * 0.55} Q ${-w / 2} ${-h + w * 0.12} 0 ${-h} Q ${w / 2} ${-h + w * 0.12} ${w / 2} ${-h + w * 0.55} L ${w / 2} 0`;
  const len = 2 * h + w * 1.2;
  return <path d={d} fill={fill} stroke={c} strokeWidth={sw} strokeLinecap="round" strokeDasharray={len} strokeDashoffset={len * (1 - draw)} />;
};
// 8-point star (geometric motif)
export const Star8: React.FC<{ r?: number; c?: string; sw?: number; o?: number }> = ({ r = 40, c = T.gold, sw = 4, o = 1 }) => (
  <g opacity={o}>
    <rect x={-r * 0.7} y={-r * 0.7} width={r * 1.4} height={r * 1.4} fill="none" stroke={c} strokeWidth={sw} />
    <rect x={-r * 0.7} y={-r * 0.7} width={r * 1.4} height={r * 1.4} fill="none" stroke={c} strokeWidth={sw} transform="rotate(45)" />
  </g>
);
