import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { T, FONT } from "../theme";
import { L, GROUND } from "../config";
import { CHUNKS } from "../data/captions";
import { StartCtx, clamp01, lin, rnd, sp, useF, vis } from "../anim";

// ── Off-white graph-paper background with colour washes (always moving) ──
export const Background: React.FC<{ night?: number }> = ({ night = 0 }) => {
  const f = useCurrentFrame();
  const ox = (f * 0.35) % 200, oy = (f * 0.2) % 200;
  const washes = [
    { x: 0.05, y: 0.08, c: "rgba(224,122,31,0.16)" },
    { x: 0.98, y: 0.12, c: "rgba(124,58,237,0.13)" },
    { x: 0.0, y: 0.72, c: "rgba(14,165,233,0.14)" },
    { x: 1.0, y: 0.66, c: "rgba(15,157,138,0.15)" },
    { x: 0.5, y: 0.98, c: "rgba(219,39,119,0.10)" },
  ];
  return (
    <AbsoluteFill style={{ background: T.paper }}>
      <svg width={L.w} height={L.h} style={{ position: "absolute" }}>
        <defs>
          <pattern id="gfine" width={40} height={40} patternUnits="userSpaceOnUse" x={ox} y={oy}>
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke={T.grid} strokeWidth={1.4} />
          </pattern>
          <pattern id="gbold" width={200} height={200} patternUnits="userSpaceOnUse" x={ox} y={oy}>
            <path d="M 200 0 L 0 0 0 200" fill="none" stroke={T.gridBold} strokeWidth={2.4} />
          </pattern>
          {washes.map((w, i) => (
            <radialGradient key={i} id={`wash${i}`} cx={w.x} cy={w.y} r={0.55}>
              <stop offset="0%" stopColor={w.c} />
              <stop offset="100%" stopColor="rgba(255,255,255,0)" />
            </radialGradient>
          ))}
          <radialGradient id="vig" cx={0.5} cy={0.45} r={0.75}>
            <stop offset="65%" stopColor="rgba(27,42,74,0)" />
            <stop offset="100%" stopColor="rgba(27,42,74,0.10)" />
          </radialGradient>
        </defs>
        {washes.map((w, i) => (
          <rect key={i} width={L.w} height={L.h} fill={`url(#wash${i})`} transform={`translate(${Math.sin(f / 90 + i) * 30} ${Math.cos(f / 110 + i) * 30})`} />
        ))}
        <rect width={L.w} height={L.h} fill="url(#gfine)" />
        <rect width={L.w} height={L.h} fill="url(#gbold)" />
        {/* floating confetti specks (multi-colour) */}
        {Array.from({ length: 26 }).map((_, i) => {
          const cols = [T.l1, T.l2, T.l3, T.pink, T.sky, T.gold, T.purple];
          const x = (rnd(i) * L.w + f * (0.15 + rnd(i + 9) * 0.3)) % L.w;
          const y = (rnd(i + 3) * L.h - f * (0.2 + rnd(i + 5) * 0.4) + L.h * 4) % L.h;
          return <circle key={i} cx={x} cy={y} r={2.5 + rnd(i + 7) * 4} fill={cols[i % cols.length]} opacity={0.22} />;
        })}
        <rect width={L.w} height={L.h} fill="url(#vig)" />
        {night > 0 && <rect width={L.w} height={L.h} fill={T.night} opacity={night * 0.18} />}
      </svg>
    </AbsoluteFill>
  );
};

// ── Ground line with soft shadow (fades at the edges) ──
export const Ground: React.FC<{ y?: number; at?: number; c?: string }> = ({ y = GROUND, at = 0, c = T.navy }) => {
  const f = useF();
  const p = lin(f, at, at + 16);
  return (
    <g opacity={p}>
      <defs>
        <linearGradient id={`gl${y}`} x1="0" x2="1">
          <stop offset="0" stopColor={c} stopOpacity={0} />
          <stop offset="0.15" stopColor={c} stopOpacity={0.8} />
          <stop offset="0.85" stopColor={c} stopOpacity={0.8} />
          <stop offset="1" stopColor={c} stopOpacity={0} />
        </linearGradient>
        <linearGradient id={`gs${y}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor={c} stopOpacity={0.10} />
          <stop offset="1" stopColor={c} stopOpacity={0} />
        </linearGradient>
      </defs>
      <rect x={0} y={y} width={L.w} height={90} fill={`url(#gs${y})`} />
      <rect x={L.w / 2 - (L.w / 2) * p} y={y - 3} width={L.w * p} height={6} rx={3} fill={`url(#gl${y})`} />
    </g>
  );
};

// ── Word-synced caption (navy pill, active word yellow block) ──
export const Caption: React.FC = () => {
  const f = useCurrentFrame();
  const t = f / 30;
  let idx = -1;
  for (let i = 0; i < CHUNKS.length; i++) {
    const c = CHUNKS[i], n = CHUNKS[i + 1];
    const until = n ? Math.min(n.start, c.end + 0.5) : c.end + 0.6;
    if (t >= c.start - 0.03 && t < until) { idx = i; break; }
  }
  // hold previous chunk across tiny gaps (< 20 frames)
  if (idx < 0) {
    for (let i = CHUNKS.length - 1; i >= 0; i--) {
      const n = CHUNKS[i + 1];
      if (t >= CHUNKS[i].end && n && n.start - CHUNKS[i].end < 0.66 && t < n.start) { idx = i; break; }
    }
  }
  if (idx < 0) return null;
  const c = CHUNKS[idx];
  let active = -1;
  c.words.forEach((w, k) => { if (t >= w.s - 0.03) active = k; });
  const p = sp(f, Math.round(c.start * 30) - 1, "snap");
  return (
    <div style={{ position: "absolute", left: 0, right: 0, top: L.caption.y, transform: `translateY(-50%) scale(${0.92 + 0.08 * p})`, display: "flex", justifyContent: "center", opacity: clamp01(p * 2.5) }}>
      <div style={{
        display: "flex", gap: 6, padding: "14px 22px", borderRadius: 26,
        background: `linear-gradient(180deg, ${T.navyLite}, ${T.navy})`, border: `2.5px solid rgba(252,211,77,0.55)`,
        boxShadow: "0 16px 34px rgba(27,42,74,0.28)", fontFamily: FONT.sans, fontWeight: 700, fontSize: L.caption.font, lineHeight: 1.12, whiteSpace: "nowrap",
      }}>
        {c.words.map((w, k) => {
          const on = k === active, done = k < active;
          return (
            <span key={k} style={{ padding: "4px 14px", borderRadius: 14, background: on ? T.highlight : "transparent", color: on ? T.navy : done ? "#FFFFFF" : "rgba(255,255,255,0.45)" }}>
              {w.w}
            </span>
          );
        })}
      </div>
    </div>
  );
};

// ── Step tab bar (1 · Physical / 2 · Status / 3 · Mission) ──
const TAB_PLAN: { a: number; b: number; act: (t: number) => number; reveal?: number[] }[] = [
  { a: 25.36, b: 85.5, act: (t) => (t < 26.42 ? 0 : t < 27.81 ? 1 : t < 33.1 ? 2 : t < 53.2 ? 0 : t < 72.7 ? 1 : 2), reveal: [25.36, 26.42, 27.81] },
  { a: 134.2, b: 999, act: (t) => (t < 135.1 ? 0 : t < 139.8 ? 1 : 2) },
];
export const TabBar: React.FC = () => {
  const f = useCurrentFrame();
  const t = f / 30;
  const plan = TAB_PLAN.find((p) => t >= p.a - 0.3 && t < p.b + 0.4);
  if (!plan) return null;
  const o = clamp01((t - plan.a + 0.3) / 0.3) * clamp01((plan.b + 0.4 - t) / 0.3);
  const act = plan.act(t);
  const names = ["1 · Physical", "2 · Status", "3 · Mission"];
  const cols = [T.l1, T.l2, T.l3];
  return (
    <div style={{ position: "absolute", top: L.tab.y, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 12, opacity: o }}>
      {names.map((n, i) => {
        const rv = plan.reveal ? sp(f, Math.round(plan.reveal[i] * 30), "snap") : 1;
        const on = i === act;
        return (
          <div key={i} style={{
            height: L.tab.h, padding: "0 26px", borderRadius: 31, display: "flex", alignItems: "center", gap: 10,
            background: on ? cols[i] : T.card, color: on ? "#FFFFFF" : T.navy, border: `2.5px solid ${on ? cols[i] : "rgba(27,42,74,0.18)"}`,
            boxShadow: on ? `0 8px 22px ${cols[i]}55` : "0 4px 10px rgba(27,42,74,0.08)",
            fontFamily: FONT.sans, fontWeight: 700, fontSize: 30, opacity: clamp01(rv * 2), transform: `scale(${(0.85 + 0.15 * rv) * (on ? 1.04 : 1)})`,
          }}>
            {!on && i < act && <span style={{ width: 12, height: 12, borderRadius: 6, background: cols[i] }} />}
            {n}
          </div>
        );
      })}
    </div>
  );
};

// ── Scene shell: provides absolute frame context + soft hand-off transitions ──
export const SceneShell: React.FC<{ start: number; end: number; children?: React.ReactNode; enter?: "fade" | "up" | "zoom" | "right"; noExit?: boolean }> = ({ start, end, children, enter = "up", noExit }) => {
  const f = useCurrentFrame() + start;
  const pin = start === 0 ? 1 : interpolate(f, [start, start + 14], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const pout = noExit ? 0 : interpolate(f, [end, end + 12], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const e = 1 - Math.pow(1 - pin, 3);
  const tr =
    enter === "zoom" ? `scale(${1.08 - 0.08 * e})` :
    enter === "right" ? `translateX(${(1 - e) * 120}px)` :
    enter === "up" ? `translateY(${(1 - e) * 60}px)` : "none";
  return (
    <StartCtx.Provider value={start}>
      <AbsoluteFill style={{ opacity: e * (1 - pout), transform: `${tr} scale(${1 - 0.04 * pout})`, filter: pout > 0.02 ? `blur(${pout * 8}px)` : undefined }}>
        {children}
      </AbsoluteFill>
    </StartCtx.Provider>
  );
};

export const Stage: React.FC<{ children?: React.ReactNode; style?: React.CSSProperties }> = ({ children, style }) => (
  <svg width={L.w} height={L.h} viewBox={`0 0 ${L.w} ${L.h}`} style={{ position: "absolute", inset: 0, overflow: "visible", ...style }}>{children}</svg>
);

// ── Text kit ──
type Seg = { t: string; c?: string; at: number; big?: boolean; mark?: boolean; font?: "display" | "sans" | "serif" };
// Kinetic line: words pop one by one at their cue
export const Kin: React.FC<{ x?: number; y: number; segs: Seg[]; size?: number; small?: number; out?: number; w?: number; align?: "center" | "left"; gap?: number }> =
  ({ x = 540, y, segs, size = 120, small = 56, out, w = 960, align = "center", gap = 18 }) => {
    const f = useF();
    const o = vis(f, 0, out, 10);
    return (
      <div style={{ position: "absolute", left: x, top: y, width: w, transform: "translateX(-50%)", display: "flex", flexWrap: "wrap", justifyContent: align === "center" ? "center" : "flex-start", alignItems: "baseline", columnGap: gap, rowGap: 0, opacity: o, transformOrigin: "center" }}>
        {segs.map((s, i) => {
          const p = sp(f, s.at, s.big ? "slam" : "pop");
          if (p <= 0.001) return <span key={i} style={{ opacity: 0, fontSize: s.big ? size : small, fontFamily: FONT.display }}>{s.t}</span>;
          const mk = s.mark ? lin(f, s.at + 4, s.at + 14) : 0;
          const fam = s.font === "serif" ? FONT.serif : s.font === "sans" || !s.big ? FONT.semi : FONT.display;
          return (
            <span key={i} style={{
              display: "inline-block", fontFamily: fam, fontWeight: s.big ? 800 : 600, fontSize: s.big ? size : small, lineHeight: 1.08,
              color: s.c ?? (s.big ? T.navy : T.ink), opacity: clamp01(p * 3),
              transform: `translateY(${(1 - p) * 34}px) scale(${s.big ? 2.0 - p : 0.5 + 0.5 * p})`,
              textShadow: s.big ? "0 3px 0 rgba(27,42,74,0.10), 0 10px 24px rgba(27,42,74,0.10)" : undefined,
              backgroundImage: s.mark ? `linear-gradient(transparent 58%, ${T.highlight} 58%, ${T.highlight} 92%, transparent 92%)` : undefined,
              backgroundSize: s.mark ? `${mk * 100}% 100%` : undefined, backgroundRepeat: "no-repeat", padding: s.mark ? "0 8px" : undefined,
            }}>{s.t}</span>
          );
        })}
      </div>
    );
  };

export const Chip: React.FC<{ x: number; y: number; at: number; out?: number; text: string; bg?: string; fg?: string; size?: number; icon?: React.ReactNode; rot?: number; border?: string }> =
  ({ x, y, at, out, text, bg = T.card, fg = T.navy, size = 36, icon, rot = 0, border }) => {
    const f = useF();
    const p = sp(f, at, "pop");
    const o = clamp01(p * 3) * vis(f, at, out);
    if (o <= 0.001) return null;
    return (
      <div style={{ position: "absolute", left: x, top: y, transform: `translate(-50%,-50%) translateY(${(1 - p) * 30}px) scale(${0.8 + 0.2 * p}) rotate(${rot}deg)`, opacity: o }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, padding: `${size * 0.32}px ${size * 0.7}px`, borderRadius: size, background: bg, color: fg, border: `3px solid ${border ?? "rgba(27,42,74,0.15)"}`, boxShadow: "0 12px 28px rgba(27,42,74,0.16)", fontFamily: FONT.semi, fontWeight: 700, fontSize: size, whiteSpace: "nowrap", lineHeight: 1.1 }}>
          {icon}{text}
        </div>
      </div>
    );
  };

export const Stamp: React.FC<{ x: number; y: number; at: number; out?: number; text: string; c?: string; size?: number; rot?: number }> = ({ x, y, at, out, text, c = T.bad, size = 64, rot = -6 }) => {
  const f = useF();
  const p = sp(f, at, "slam");
  const o = clamp01(p * 4) * vis(f, at, out);
  if (o <= 0.001) return null;
  return (
    <div style={{ position: "absolute", left: x, top: y, transform: `translate(-50%,-50%) scale(${2.2 - 1.2 * p}) rotate(${rot}deg)`, opacity: o }}>
      <div style={{ padding: `${size * 0.18}px ${size * 0.45}px`, border: `${size * 0.09}px solid ${c}`, borderRadius: size * 0.25, color: c, fontFamily: FONT.display, fontWeight: 800, fontSize: size, letterSpacing: 1, background: "rgba(255,253,247,0.92)", whiteSpace: "nowrap", boxShadow: "0 10px 24px rgba(27,42,74,0.14)" }}>{text}</div>
    </div>
  );
};

// Card container (HTML)
export const Card: React.FC<{ x: number; y: number; w: number; h?: number; at: number; out?: number; children?: React.ReactNode; border?: string; rot?: number; bg?: string; pad?: number; k?: "pop" | "soft" }> =
  ({ x, y, w, h, at, out, children, border = "rgba(27,42,74,0.14)", rot = 0, bg = T.card, pad = 24, k = "pop" }) => {
    const f = useF();
    const p = sp(f, at, k);
    const o = clamp01(p * 3) * vis(f, at, out);
    if (o <= 0.001) return null;
    return (
      <div style={{ position: "absolute", left: x, top: y, width: w, height: h, transform: `translateX(-50%) translateY(${(1 - p) * 50}px) scale(${0.9 + 0.1 * p}) rotate(${rot}deg)`, opacity: o, filter: p < 0.5 ? `blur(${(1 - p * 2) * 8}px)` : undefined }}>
        <div style={{ width: "100%", height: "100%", boxSizing: "border-box", padding: pad, borderRadius: 30, background: bg, border: `3px solid ${border}`, boxShadow: "0 18px 40px rgba(27,42,74,0.18)" }}>{children}</div>
      </div>
    );
  };

// Light cone from top (big reveal)
export const TopLight: React.FC<{ at: number; x?: number; c?: string; w?: number; y2?: number }> = ({ at, x = 540, c = T.gold, w = 520, y2 = 1200 }) => {
  const f = useF();
  const p = lin(f, at, at + 18);
  if (p <= 0) return null;
  const fl = 0.85 + 0.15 * Math.sin(f / 10);
  return (
    <g opacity={p * fl}>
      <defs>
        <linearGradient id={`tl${at}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor={c} stopOpacity={0.55} />
          <stop offset="1" stopColor={c} stopOpacity={0} />
        </linearGradient>
      </defs>
      <path d={`M ${x - 70} 0 L ${x + 70} 0 L ${x + w / 2} ${y2} L ${x - w / 2} ${y2} Z`} fill={`url(#tl${at})`} />
    </g>
  );
};

// Sparkles around a point
export const Sparkles: React.FC<{ x: number; y: number; at: number; n?: number; r?: number; c?: string }> = ({ x, y, at, n = 10, r = 200, c = T.gold }) => {
  const f = useF();
  if (f < at) return null;
  return (
    <g>
      {Array.from({ length: n }).map((_, i) => {
        const a = rnd(i + at) * Math.PI * 2;
        const period = 40 + rnd(i * 3) * 30;
        const ph = ((f - at + rnd(i + 1) * period) % period) / period;
        const rr = r * (0.5 + rnd(i + 2) * 0.6);
        const sx = x + Math.cos(a) * rr, sy = y + Math.sin(a) * rr - ph * 30;
        const sc = Math.sin(ph * Math.PI) * (8 + rnd(i) * 8);
        return <path key={i} d={`M ${sx} ${sy - sc} L ${sx + sc * 0.3} ${sy - sc * 0.3} L ${sx + sc} ${sy} L ${sx + sc * 0.3} ${sy + sc * 0.3} L ${sx} ${sy + sc} L ${sx - sc * 0.3} ${sy + sc * 0.3} L ${sx - sc} ${sy} L ${sx - sc * 0.3} ${sy - sc * 0.3} Z`} fill={c} />;
      })}
    </g>
  );
};
