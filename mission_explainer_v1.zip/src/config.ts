// One place for ratio & timing. Change ASPECT here if a 16:9 version is needed (layout presets in RATIOS).
export const ASPECT = "9:16" as const;
export const RATIOS = {
  "9:16": { w: 1080, h: 1920, margin: 70, tab: { y: 150, h: 62 }, stage: { top: 280, bottom: 1300 }, caption: { y: 1398, font: 60 }, reserveFrom: 1500, k: 1 },
  "16:9": { w: 1920, h: 1080, margin: 100, tab: { y: 44, h: 56 }, stage: { top: 160, bottom: 850 }, caption: { y: 940, font: 52 }, reserveFrom: 1000, k: 0.7 },
} as const;
export const L = RATIOS[ASPECT];
export const FPS = 30;
export const AUDIO_SEC = 142.96;
export const HOLD_SEC = 1;
export const DURATION = Math.round((AUDIO_SEC + HOLD_SEC) * FPS); // 4319
export const GROUND = 1180; // ground line y (9:16 art is authored on a 1080x1920 canvas)
