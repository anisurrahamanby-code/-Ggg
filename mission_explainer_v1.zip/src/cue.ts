import { WORDS } from "./data/words";
import { FPS } from "./config";
// Frame where a spoken word starts. `after` (sec) picks the first match at/after that time.
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9']/g, "");
export const cueSec = (word: string, after = 0): number => {
  const n = norm(word);
  const w = WORDS.find((x) => x[1] >= after - 0.001 && norm(x[0]) === n);
  if (!w) throw new Error(`cue not found: ${word} after ${after}`);
  return w[1];
};
// visual cue = word start - 0.08 s (rule); exact = word start (numbers, stamps)
export const cue = (word: string, after = 0) => Math.round((cueSec(word, after) - 0.08) * FPS);
export const at = (word: string, after = 0) => Math.round(cueSec(word, after) * FPS);
export const sec = (s: number) => Math.round(s * FPS);
