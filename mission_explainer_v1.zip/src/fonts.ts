import { useEffect, useState } from "react";
import { continueRender, delayRender, staticFile } from "remotion";

const FACES = [
  { family: "AnekC", file: "AnekBangla_Condensed-ExtraBold.ttf", weight: "800", style: "normal" },
  { family: "AnekSC", file: "AnekBangla_SemiCondensed-Bold.ttf", weight: "700", style: "normal" },
  { family: "AnekSC", file: "AnekBangla_SemiCondensed-SemiBold.ttf", weight: "600", style: "normal" },
  { family: "Hind", file: "HindSiliguri-SemiBold.ttf", weight: "600", style: "normal" },
  { family: "Hind", file: "HindSiliguri-Bold.ttf", weight: "700", style: "normal" },
  { family: "Tiro", file: "TiroBangla-Regular.ttf", weight: "400", style: "normal" },
  { family: "Tiro", file: "TiroBangla-Italic.ttf", weight: "400", style: "italic" },
];

const withTimeout = <T,>(p: Promise<T>, ms: number) =>
  Promise.race([p, new Promise<void>((r) => setTimeout(r, ms))]);

export const useFonts = () => {
  const [handle] = useState(() => delayRender("fonts", { timeoutInMilliseconds: 120000 }));
  useEffect(() => {
    const css = FACES.map(
      (f) => `@font-face{font-family:'${f.family}';src:url('${staticFile("fonts/" + f.file)}');font-weight:${f.weight};font-style:${f.style};font-display:block;}`
    ).join("\n");
    const st = document.createElement("style");
    st.innerHTML = css;
    document.head.appendChild(st);
    Promise.all(
      FACES.map((f) =>
        withTimeout(
          new FontFace(f.family, `url('${staticFile("fonts/" + f.file)}')`, { weight: f.weight, style: f.style })
            .load()
            .then((l) => {
              (document.fonts as any).add(l);
            })
            .catch(() => {}),
          25000
        )
      )
    ).then(() => continueRender(handle));
  }, [handle]);
};
