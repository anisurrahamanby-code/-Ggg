import React from "react";
import { T, FONT } from "../theme";
import { GROUND } from "../config";
import { cue, at } from "../cue";
import { Idle, Mover, Pop, Ring, clamp01, lin, sp, useF, vis } from "../anim";
import { Chip, Ground, Kin, Stage } from "../components/Base";
import { Dog, Person, DogPose } from "../art/Characters";
import { Bowl, Bed, Check, DogHouse, Heart } from "../art/Props";

// 0 – 10.9 s : a dog's life → you do the same → what is the real difference?
export const SceneA: React.FC = () => {
  const f = useF();
  const cEat = cue("eats"), cSleep = cue("sleeps"), cGuard = cue("guards"), cTerr = cue("territory"), cLooks = cue("looks"), cMate = cue("mate");
  const cYou = cue("You", 4.9), cExact = cue("exact"), cSame = cue("same"), cSo = cue("So", 6.5), cWhat = cue("what", 7), cReal = cue("real", 8), cLife = cue("life", 9), cDogs = cue("dog's");
  const pose: DogPose = f < cEat ? "stand" : f < cSleep + 2 ? "eat" : f < cGuard ? "sleep" : "stand";
  const dogTo = cYou;
  const badges = [
    { x: 187, label: "EATS", c: T.l1, at: cEat, icon: <Bowl s={0.62} /> },
    { x: 422, label: "SLEEPS", c: T.l2, at: cSleep, icon: <Bed s={0.66} /> },
    { x: 657, label: "GUARDS", c: T.bad, at: cGuard, icon: <g transform="translate(0 40)"><DogHouse s={0.42} /></g> },
    { x: 892, label: "FINDS A MATE", c: T.pink, at: cMate - 4, icon: <Heart s={0.75} /> },
  ];
  const badgesOut = cSo - 4;
  const terr = lin(f, cTerr, cTerr + 20);
  return (
    <>
      <Stage>
        <Ground at={-16} />
        {/* territory ring + dog house (behind dog) */}
        <Pop at={cGuard} out={cYou - 8} x={200} y={GROUND} s={0.95}><DogHouse /></Pop>
        {f >= cTerr && f < cYou && (
          <ellipse cx={420} cy={GROUND} rx={330} ry={70} fill="rgba(200,30,30,0.06)" stroke={T.bad} strokeWidth={6} strokeDasharray="22 16"
            strokeDashoffset={-f * 2} opacity={terr * vis(f, cTerr, cYou - 10)} pathLength={1000} />
        )}
        {/* bowl */}
        <Pop at={cEat - 3} out={cLooks} x={770} y={GROUND - 6} s={0.95} k="snap"><Bowl /></Pop>
        {/* main dog: moves left when "you" enters */}
        <Mover from={[440, GROUND]} to={[250, GROUND]} start={dogTo} dur={16} bob={6}>
          <Pop at={-10} s={1.35} k="soft" dy={120}>
            <Idle amp={pose === "sleep" ? 1.5 : 2.5} speed={pose === "sleep" ? 1.2 : 2.4}>
              <Dog pose={pose} />
            </Idle>
          </Pop>
        </Mover>
        {/* Zzz while sleeping */}
        {f >= cSleep && f < cGuard + 8 && <g transform={`translate(620 ${GROUND - 220})`} opacity={vis(f, cSleep, cGuard)}><Zzzz /></g>}
        {/* second dog + heart */}
        <Pop at={cLooks} out={cYou - 8} x={905} y={GROUND} s={0.85} k="pop"><Idle amp={2} phase={1}><Dog body={T.dog2} dark="#6E6E6E" collar={T.pink} flip /></Idle></Pop>
        <Pop at={cMate} out={cYou - 8} x={780} y={GROUND - 330} s={1.0} k="slam"><Idle amp={6} speed={4}><Heart s={1.0} /></Idle></Pop>
        {f >= cMate && f < cYou && <Ring x={780} y={GROUND - 330} r={50} color={T.pink} start={cMate} />}
        {/* you enter */}
        <Mover from={[1260, GROUND]} to={[840, GROUND]} start={cYou - 6} dur={16} bob={8} tilt={2}>
          <Idle amp={2.5} phase={2}>
            <Person pose={f < cYou + 10 ? "walk" : f >= cWhat ? "stand" : "point"} scale={1.7} cloth={T.l3} flip={false} mood={f >= cWhat ? "open" : "smile"} />
          </Idle>
        </Mover>
        {/* equals between them */}
        <Pop at={cSame} out={cWhat - 8} x={625} y={GROUND - 190} s={1} k="slam">
          <rect x={-55} y={-42} width={110} height={26} rx={13} fill={T.l3} stroke={T.line} strokeWidth={5} />
          <rect x={-55} y={14} width={110} height={26} rx={13} fill={T.l3} stroke={T.line} strokeWidth={5} />
        </Pop>
        {/* question mark */}
        <Pop at={cWhat} x={620} y={GROUND - 110} s={1} k="slam">
          <Idle amp={8} speed={3}>
            <text x={0} y={0} textAnchor="middle" fontFamily={FONT.display} fontSize={330} fill={T.purple} stroke={T.line} strokeWidth={8} paintOrder="stroke">?</text>
          </Idle>
        </Pop>
        {f >= cWhat && <Ring x={620} y={GROUND - 220} r={120} color={T.purple} start={cWhat} period={40} />}
        {/* badges row */}
        {badges.map((b, i) => (
          <g key={i}>
            <Pop at={b.at} out={badgesOut + i * 2} x={b.x} y={650} s={1} k="pop" dy={50}>
              <circle r={86} fill={T.card} stroke={b.c} strokeWidth={9} />
              <circle r={86} fill="none" stroke={T.line} strokeWidth={3} opacity={0.25} />
              <g transform="translate(0 8)">{b.icon}</g>
            </Pop>
            {/* ✓ ticks: you do the same */}
            <Pop at={cExact + i * 3} out={badgesOut + i * 2} x={b.x + 64} y={650 - 62} s={1} k="slam"><Check s={1.1} /></Pop>
          </g>
        ))}
      </Stage>
      {/* badge labels */}
      {badges.map((b, i) => {
        const p = sp(f, b.at + 2, "snap");
        const o = clamp01(p * 3) * vis(f, b.at, badgesOut + i * 2);
        return o > 0 ? (
          <div key={i} style={{ position: "absolute", left: b.x, top: 752, transform: `translateX(-50%) scale(${0.8 + 0.2 * p})`, opacity: o, fontFamily: FONT.semi, fontWeight: 700, fontSize: 30, color: T.navy, whiteSpace: "nowrap", background: T.card, padding: "4px 14px", borderRadius: 14, border: `2.5px solid ${b.c}` }}>{b.label}</div>
        ) : null;
      })}
      {/* titles */}
      <Kin y={300} out={cYou - 8} segs={[{ t: "A DOG'S", at: -8, big: true, c: T.l1 }, { t: "LIFE", at: -2, big: true, mark: true }]} size={118} />
      <Kin y={300} out={cSo - 6} segs={[{ t: "you do the", at: cYou }, { t: "EXACT SAME", at: cExact, big: true, mark: true, c: T.l3 }]} size={112} small={58} />
      <Kin y={290} segs={[{ t: "so what is the", at: cSo }, { t: "REAL", at: cReal, big: true, c: T.bad, mark: true }, { t: "DIFFERENCE?", at: cReal + 6, big: true }]} size={112} small={58} />
      <Chip x={800} y={1262} at={cLife} text="YOUR LIFE" bg={T.l3} fg="#fff" size={34} border={T.l3} />
      <Chip x={300} y={1262} at={cDogs} text="A DOG'S LIFE" bg={T.l1} fg="#fff" size={34} border={T.l1} />
    </>
  );
};

const Zzzz: React.FC = () => {
  const f = useF();
  return (
    <g>
      {[0, 1, 2].map((i) => {
        const t = ((f / 30 + i * 0.4) % 1.2) / 1.2;
        return <text key={i} x={i * 30 + t * 14} y={-i * 34 - t * 26} fontFamily={FONT.display} fontSize={44 + i * 14} fill={T.l2} opacity={1 - t * 0.7}>Z</text>;
      })}
    </g>
  );
};
