import React from "react";
import { Img, staticFile } from "remotion";
import { T, FONT } from "../theme";
import { GROUND } from "../config";
import { cue, at } from "../cue";
import { Idle, Mover, Pop, Ring, clamp01, lin, sp, useF, INOUT } from "../anim";
import { Chip, Ground, Kin, Stage, Sparkles } from "../components/Base";
import { Dog, Person } from "../art/Characters";
import { Ladder } from "../art/Ladder";

// 10.9 – 15.3 s : the difference is a ladder — the ladder of human needs
export const SceneB: React.FC = () => {
  const f = useF();
  const cLadder = cue("ladder", 11.5), cYes = cue("Yes"), cHuman = cue("human", 14), cNeeds = cue("needs", 14.5);
  return (
    <>
      <Stage>
        <Ground at={0} />
        <Ladder x={540} ground={GROUND} h={640} w={300} at={cLadder - 14} rungAt={[cLadder - 4, cLadder + 2, cLadder + 8]} />
        {f >= cLadder && <Ring x={540} y={GROUND - 400} r={200} color={T.gold} start={cLadder} period={45} width={6} />}
        <Pop at={0} x={170} y={GROUND} s={1.45} k="soft"><Idle amp={2.5}><Person pose={f > cYes ? "point" : "stand"} flip={false} mood="open" /></Idle></Pop>
        <Pop at={0} x={895} y={GROUND} s={0.85} k="soft"><Idle amp={2} phase={1}><Dog pose="sit" flip /></Idle></Pop>
      </Stage>
      <Kin y={262} segs={[{ t: "the difference is a", at: cue("The", 11) }, { t: "LADDER", at: cLadder, big: true, c: T.l1 }]} size={120} small={56} />
      <Kin y={400} segs={[{ t: "of", at: cue("of", 13.9) }, { t: "HUMAN NEEDS", at: cHuman, big: true, mark: true }]} size={84} small={52} />
    </>
  );
};

// 15.3 – 23.0 s : 1943, psychologist Abraham Maslow, hierarchy of needs = this ladder
export const SceneC: React.FC = () => {
  const f = useF();
  const c1943 = at("1943"), cPsy = cue("psychologist"), cAbr = cue("Abraham"), cIntro = cue("introduced"), cHier = cue("Maslow's"), cThis = cue("this", 21.8), cLad = cue("ladder", 22.3);
  const ph = sp(f, cue("In", 15.4), "soft");
  const kb = 1.04 + 0.14 * lin(f, 460, 700, INOUT);
  const arrow = lin(f, cThis, cThis + 16, INOUT);
  return (
    <>
      <Stage>
        <Ground at={0} />
        <g opacity={1}>
          <Ladder x={845} ground={GROUND} h={560} w={190} at={0} rungAt={[0, 2, 4]} numbers={false} glow3={lin(f, cLad, cLad + 12)} />
        </g>
        {f >= cLad && <Ring x={845} y={GROUND - 300} r={160} color={T.l3} start={cLad} period={36} width={6} />}
        {/* dashed arrow photo → ladder */}
        {arrow > 0 && (
          <g>
            <path d="M 560 820 Q 680 700 742 800" fill="none" stroke={T.purple} strokeWidth={7} strokeLinecap="round" pathLength={100} strokeDasharray={`${arrow * 100} 100`} />
            <path d="M 742 800 l -26 -10 l 10 -24" fill="none" stroke={T.purple} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" opacity={arrow > 0.95 ? 1 : 0} />
          </g>
        )}
      </Stage>
      {/* real photo, polaroid frame */}
      <div style={{ position: "absolute", left: 330, top: 430, transform: `translateX(-50%) translateY(${(1 - ph) * 80}px) rotate(${-3 + (1 - ph) * -6}deg) scale(${0.9 + 0.1 * ph})`, opacity: clamp01(ph * 3) }}>
        <div style={{ width: 470, padding: "16px 16px 64px", background: T.card, borderRadius: 18, boxShadow: "0 24px 50px rgba(27,42,74,0.28)", border: "2px solid rgba(27,42,74,0.12)" }}>
          <div style={{ width: 438, height: 540, overflow: "hidden", borderRadius: 8, position: "relative" }}>
            <Img src={staticFile("img/maslow.jpg")} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "50% 30%", transform: `scale(${kb})`, transformOrigin: "50% 35%", filter: "sepia(0.12) contrast(1.05)" }} />
            <div style={{ position: "absolute", inset: 0, boxShadow: "inset 0 0 60px rgba(0,0,0,0.25)" }} />
          </div>
          <div style={{ position: "absolute", left: 30, bottom: 16, fontFamily: FONT.serif, fontStyle: "italic", fontSize: 30, color: T.ink }}>Abraham Maslow</div>
        </div>
        <div style={{ position: "absolute", top: -18, left: -16, background: T.bad, color: "#fff", fontFamily: FONT.semi, fontWeight: 700, fontSize: 26, padding: "6px 16px", borderRadius: 10, transform: "rotate(-4deg)", boxShadow: "0 8px 18px rgba(200,30,30,0.3)" }}>REAL PHOTO</div>
        <div style={{ position: "absolute", top: -10, right: 60, width: 120, height: 34, background: "rgba(252,211,77,0.75)", transform: "rotate(4deg)" }} />
      </div>
      <Kin y={268} x={330} w={600} segs={[{ t: "in", at: cue("In", 15.4) }, { t: "1943", at: c1943, big: true, c: T.l2, mark: true }]} size={118} small={56} />
      <Chip x={330} y={1222} at={cPsy} text="PSYCHOLOGIST" bg={T.l2} fg="#fff" border={T.l2} size={34} />
      <Kin y={1078} x={330} w={640} segs={[{ t: "ABRAHAM MASLOW", at: cAbr, big: true }]} size={64} />
      <Kin y={300} x={845} w={420} segs={[{ t: "Maslow's", at: cHier, c: T.l2 }, { t: "HIERARCHY", at: cue("hierarchy") - 2, big: true, c: T.l3 }, { t: "OF NEEDS", at: cue("needs", 21) - 2, big: true }]} size={70} small={46} gap={8} />
      <Chip x={845} y={1240} at={cLad} text="THIS LADDER" bg={T.highlight} fg={T.navy} border={T.navy} size={32} />
      <Sparkles x={845} y={GROUND - 420} at={cLad} n={8} r={150} />
    </>
  );
};
