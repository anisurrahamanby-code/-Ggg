import React from "react";
import { T, FONT } from "../theme";
import { GROUND } from "../config";
import { cue, at } from "../cue";
import { Idle, Pop, Ring, clamp01, lin, sp, useF, vis } from "../anim";
import { Chip, Ground, Kin, Stage, Stamp } from "../components/Base";
import { Person } from "../art/Characters";
import { Ladder, rungY, LEVEL_COLORS } from "../art/Ladder";
import { Bed, Bubble, Calendar, Check, Cross, Crown, Glass, Medal, Plate, Speaker, Star, Trophy } from "../art/Props";

// 23.0 – 33.1 s : three levels; lower needs first, upper locked
export const SceneD: React.FC = () => {
  const f = useF();
  const cThree = cue("three", 24), cPhys = cue("physical", 25), cStat = cue("status", 26), cMis = cue("mission", 27.5);
  const cHe = cue("He", 28.5), cUntil = cue("until", 29), cMet = cue("met", 30), cCant = cue("can't", 31), cHigh = cue("higher", 32);
  const H = 800, X = 380;
  const labels = [
    { t: "PHYSICAL NEEDS", at: cPhys, icons: [<Plate key="a" s={0.42} empty={false} />, <Glass key="b" s={0.4} />, <Bed key="c" s={0.4} />] },
    { t: "STATUS NEEDS", at: cStat, icons: [<Crown key="a" s={0.42} />, <Star key="b" s={0.42} />, <Trophy key="c" s={0.4} />] },
    { t: "MISSION", at: cMis, icons: [] },
  ];
  const dim = lin(f, cCant, cCant + 14);
  return (
    <>
      <Stage>
        <Ground at={0} />
        <Ladder x={X} ground={GROUND} h={H} w={260} at={0} rungAt={[cPhys - 4, cStat - 4, cMis - 4]} locked={[1, 2]} lockAt={cUntil} lit={f >= cMet ? [0] : []} dimUpper={dim} glow3={lin(f, cMis, cMis + 10) * (1 - dim * 0.7)} />
        {labels.map((l, i) => {
          const y = rungY(GROUND, H, i) + 18;
          return (
            <Pop key={i} at={l.at} x={800} y={y} s={1} k="pop" dy={30}>
              <g opacity={i > 0 ? 1 - dim * 0.55 : 1}>
                <rect x={-200} y={-62} width={400} height={124} rx={28} fill={T.card} stroke={LEVEL_COLORS[i]} strokeWidth={6} />
                <text x={0} y={i === 2 ? 16 : -12} textAnchor="middle" fontFamily={FONT.display} fontSize={i === 2 ? 52 : 40} fill={i === 2 ? T.l3 : T.navy}>{l.t}</text>
                {l.icons.map((ic, k) => <g key={k} transform={`translate(${-90 + k * 90} 30)`}>{ic}</g>)}
              </g>
            </Pop>
          );
        })}
        {/* connector ticks from rung to labels */}
        {[0, 1, 2].map((i) => {
          const p = lin(f, labels[i].at, labels[i].at + 10);
          const y = rungY(GROUND, H, i) + 18;
          return p > 0 ? <line key={i} x1={X + 160} y1={y} x2={X + 160 + (440 - 160 - 60) * p} y2={y} stroke={LEVEL_COLORS[i]} strokeWidth={5} strokeDasharray="10 10" opacity={i > 0 ? 1 - dim * 0.5 : 1} /> : null;
        })}
        {/* person at the foot of the ladder */}
        <Pop at={cHe} x={X - 10} y={GROUND} s={1.25} k="pop"><Idle amp={2}><Person pose={f >= cHigh ? "point" : "stand"} cloth={T.l3} mood={f >= cCant ? "open" : "smile"} /></Idle></Pop>
        <Pop at={cMet} x={1030} y={rungY(GROUND, H, 0) - 40} s={1} k="slam"><Check s={1.2} /></Pop>
      </Stage>
      <Kin y={250} segs={[{ t: "three main", at: cThree - 4 }, { t: "LEVELS", at: cue("levels", 24.5), big: true, c: T.purple }]} size={96} small={52} />
      <Chip x={190} y={1250} at={cUntil} text="LOWER FIRST" bg={T.l1} fg="#fff" border={T.l1} size={32} />
    </>
  );
};

// 33.1 – 47.2 s : level 1 — hungry for two days, Nobel prize? not at all; hunger, thirst, sleep; others silent
export const SceneE: React.FC = () => {
  const f = useF();
  const cFirst = cue("first", 33.9), cImag = cue("Imagine"), cEaten = cue("eaten"), cTwo = at("two", 37), cNobel = cue("Nobel"), cNot = at("Not", 40.5);
  const cHun = cue("hunger", 42), cThi = cue("thirst", 42.5), cSle = cue("sleep", 43.5), cSat = cue("satisfied", 44), cEvery = cue("every", 45), cSil = cue("silent", 46);
  const phaseA = f < cHun - 6;
  const slump = f >= cImag && f < cSat + 4;
  const tiles = [
    { x: 220, t: "HUNGER", c: T.l1, at: cHun, icon: <Plate s={0.8} empty={f < cSat} /> },
    { x: 540, t: "THIRST", c: T.sky, at: cThi, icon: <Glass s={0.85} fill={f < cSat ? 0.05 : 0.05 + 0.75 * lin(f, cSat, cSat + 20)} /> },
    { x: 860, t: "SLEEP", c: T.l2, at: cSle, icon: <Bed s={0.85} /> },
  ];
  const fill = lin(f, cSat - 2, cSat + 22);
  const counter = Math.round(2 * lin(f, cTwo - 16, cTwo));
  return (
    <>
      <Stage>
        <Ground at={0} />
        {/* person */}
        <Pop at={0} x={300} y={GROUND} s={1.6} k="soft">
          <g transform={`rotate(${slump ? -4 : 0})`}>
            <Idle amp={slump ? 1.2 : 2.5} speed={slump ? 1.2 : 2}>
              <Person pose={slump ? "slump" : "stand"} cloth={T.l3} mood={slump ? "sad" : "smile"} />
            </Idle>
          </g>
        </Pop>
        {/* hunger zig-zag lines at belly */}
        {slump && f >= cEaten && (
          <g opacity={vis(f, cEaten, cSat)} stroke={T.l1} strokeWidth={6} fill="none" strokeLinecap="round">
            {[0, 1].map((i) => {
              const w = Math.sin(f / 3 + i) * 4;
              return <path key={i} d={`M ${370 + i * 22} ${GROUND - 200 + i * 30 + w} l 14 -10 l 0 20 l 14 -10`} />;
            })}
          </g>
        )}
        {/* plate on the floor */}
        <Pop at={cEaten} x={560} y={GROUND - 26} s={1.15} k="snap"><Plate empty={f < cSat} /></Pop>
        {/* calendar: two days */}
        <Pop at={cTwo - 16} out={cHun - 12} x={830} y={450} s={1.3} k="pop"><Idle amp={3}><Calendar n={counter} /></Idle></Pop>
        {/* Nobel thought bubble */}
        <Pop at={cNobel - 4} out={cNot + 10} x={760} y={830} s={1} k="pop">
          <Bubble w={380} h={250} tailX={-200} tailY={150} />
          <g transform="translate(-90 6)"><Medal s={1.05} /></g>
          <text x={70} y={-10} textAnchor="middle" fontFamily={FONT.display} fontSize={46} fill={T.navy}>NOBEL</text>
          <text x={70} y={40} textAnchor="middle" fontFamily={FONT.display} fontSize={46} fill={T.navy}>PRIZE?</text>
        </Pop>
        <Pop at={cNot} out={cNot + 10} x={760} y={830} s={1.6} k="slam"><Cross /></Pop>
        {/* need tiles */}
        {tiles.map((t, i) => (
          <Pop key={i} at={t.at} x={t.x} y={560} s={1} k="pop">
            <rect x={-140} y={-150} width={280} height={300} rx={34} fill={T.card} stroke={t.c} strokeWidth={7} />
            <g transform="translate(0 -40)">{t.icon}</g>
            <text y={70} textAnchor="middle" fontFamily={FONT.display} fontSize={46} fill={T.navy}>{t.t}</text>
            <rect x={-100} y={96} width={200} height={22} rx={11} fill="#E7E2D6" />
            <rect x={-100} y={96} width={200 * fill} height={22} rx={11} fill={T.good} />
            {fill > 0.98 && <g transform="translate(118 -128)"><Check s={1.1} /></g>}
          </Pop>
        ))}
        {/* other needs: silent */}
        <Pop at={cEvery} x={790} y={1000} s={1} k="soft">
          <g opacity={0.55}>
            <rect x={-200} y={-150} width={400} height={240} rx={30} fill="#ECE8DF" stroke={T.muted} strokeWidth={4} strokeDasharray="14 10" />
            <g transform="translate(-110 -50)"><Crown s={0.6} c="#C9C4B8" /></g>
            <g transform="translate(0 -50)"><Star s={0.6} c="#C9C4B8" /></g>
            <g transform="translate(110 -50)"><Trophy s={0.55} c="#C9C4B8" /></g>
          </g>
          <text y={50} textAnchor="middle" fontFamily={FONT.display} fontSize={40} fill={T.muted}>OTHER NEEDS</text>
        </Pop>
        <Pop at={cSil - 6} x={980} y={880} s={1.2} k="slam"><circle r={56} fill={T.card} stroke={T.bad} strokeWidth={5} /><g transform="translate(-8 0)"><Speaker s={0.75} /></g></Pop>
      </Stage>
      <Kin y={250} out={cHun - 12} segs={[{ t: "LEVEL 1", at: cFirst, big: true, c: T.l1 }, { t: "physical needs", at: cue("physical", 34.5) }]} size={96} small={54} />
      <Chip x={830} y={600} at={cue("days", 37.5)} out={cHun - 12} text="2 DAYS · NO FOOD" bg={T.bad} fg="#fff" border={T.bad} size={32} />
      <Kin y={250} segs={[{ t: "until these are", at: cHun }, { t: "SATISFIED", at: cSat, big: true, c: T.good, mark: true }]} size={84} small={50} />
      <Stamp x={790} y={1150} at={cSil} text="SILENT" c={T.muted} size={50} rot={-5} />
    </>
  );
};
