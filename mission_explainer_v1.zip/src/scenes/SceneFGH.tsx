import React from "react";
import { T, FONT } from "../theme";
import { GROUND } from "../config";
import { cue, at } from "../cue";
import { Idle, Mover, Pop, Ring, clamp01, lin, sp, useF, vis, INOUT } from "../anim";
import { Chip, Ground, Kin, Stage, Stamp, Sparkles } from "../components/Base";
import { Dog, Person } from "../art/Characters";
import { Ladder, rungY } from "../art/Ladder";
import { Bowl, Crown, NamePlate, Plate, Post, Star, Trophy } from "../art/Props";

const Equals: React.FC<{ c?: string }> = ({ c = T.l3 }) => (
  <g>
    <rect x={-50} y={-38} width={100} height={24} rx={12} fill={c} stroke={T.line} strokeWidth={5} />
    <rect x={-50} y={12} width={100} height={24} rx={12} fill={c} stroke={T.line} strokeWidth={5} />
  </g>
);

// 47.2 – 53.2 s : a dog is the same way → level 1, no difference
export const SceneF: React.FC = () => {
  const f = useF();
  const cDog = cue("dog", 47.5), cExact = cue("exact", 48), cSo = cue("So", 49.2), cNo = at("no", 50.7), cHum = cue("human", 51.8), cDog2 = cue("dog", 52.5);
  const plat = sp(f, cSo, "pop");
  return (
    <>
      <Stage>
        <Ground at={0} />
        {/* amber level-1 platform */}
        <g opacity={clamp01(plat * 3)} transform={`translate(540 ${GROUND}) scale(${0.7 + 0.3 * plat} 1) translate(-540 ${-GROUND})`}>
          <rect x={90} y={GROUND - 4} width={900} height={44} rx={22} fill={T.l1} stroke={T.line} strokeWidth={5} />
          <circle cx={130} cy={GROUND + 18} r={30} fill={T.card} stroke={T.l1} strokeWidth={6} />
          <text x={130} y={GROUND + 32} textAnchor="middle" fontFamily={FONT.display} fontSize={38} fill={T.navy}>1</text>
        </g>
        <Pop at={0} x={300} y={GROUND} s={1.55} k="soft"><Idle amp={2.5}><Person pose="stand" cloth={T.l3} /></Idle></Pop>
        <Pop at={0} x={170} y={GROUND - 22} s={0.6} k="soft"><Plate empty={false} /></Pop>
        <Pop at={cDog} x={600} y={GROUND - 8} s={0.75} k="snap"><Bowl /></Pop>
        <Mover from={[1300, GROUND]} to={[830, GROUND]} start={cDog - 8} dur={18} bob={7}>
          <Idle amp={2} phase={1}><g transform="scale(1.15)"><Dog pose={f >= cExact + 6 && f < cSo + 10 ? "eat" : "stand"} flip /></g></Idle>
        </Mover>
        <Pop at={cExact} x={500} y={GROUND - 250} s={1.1} k="slam"><Equals c={T.l1} /></Pop>
        {f >= cNo && <Ring x={500} y={GROUND - 250} r={90} color={T.l1} start={cNo} />}
      </Stage>
      <Kin y={262} segs={[{ t: "a dog is the", at: cDog }, { t: "EXACT SAME", at: cExact, big: true, c: T.l1, mark: true }]} size={100} small={54} out={cSo + 20} />
      <Kin y={262} segs={[{ t: "at this level:", at: cSo + 22 }, { t: "NO", at: cNo, big: true, c: T.bad }, { t: "DIFFERENCE", at: cNo + 6, big: true }]} size={100} small={54} />
      <Chip x={300} y={1262} at={cHum} text="HUMAN" bg={T.l3} fg="#fff" border={T.l3} size={34} />
      <Chip x={790} y={1262} at={cDog2} text="DOG" bg={T.dogDark} fg="#fff" border={T.dogDark} size={34} />
    </>
  );
};

// 53.2 – 62.85 s : level 2 — status needs: big title, fame, power, respect
export const SceneG: React.FC = () => {
  const f = useF();
  const cOnce = cue("Once"), cReach = cue("reach"), cSecond = cue("second"), cStat = cue("status", 56), cWhen = cue("When", 57.3), cTitle = cue("title"), cFame = cue("fame", 60), cPow = cue("power"), cResp = cue("respect");
  const H = 800, X = 280;
  const items = [
    { at: cTitle, t: "BIG TITLE", c: T.l2, icon: <NamePlate s={0.85} text="TITLE" /> },
    { at: cFame, t: "FAME", c: T.pink, icon: <Star s={0.75} c={T.gold} /> },
    { at: cPow, t: "POWER", c: T.purple, icon: <Crown s={0.8} /> },
    { at: cResp, t: "RESPECT", c: T.l3, icon: <Trophy s={0.75} /> },
  ];
  const y1 = rungY(GROUND, H, 0), y2 = rungY(GROUND, H, 1);
  return (
    <>
      <Stage>
        <Ground at={0} />
        <Ladder x={X} ground={GROUND} h={H} w={240} at={0} rungAt={[0, 2, 4]} lit={f >= cReach + 10 ? [1] : [0]} locked={f < cReach ? [1, 2] : [2]} lockAt={-20} />
        {items.map((it, i) => {
          const y = 470 + i * 200;
          const p = lin(f, it.at + 4, it.at + 16, INOUT);
          return p > 0 ? <path key={i} d={`M ${X + 70} ${y2 - 150} L ${X + 70 + (620 - X - 70 - 170) * p} ${y + (y2 - 150 - y) * (1 - p)}`} stroke={it.c} strokeWidth={5} strokeDasharray="10 10" fill="none" opacity={0.8} /> : null;
        })}
        <Mover from={[X, y1]} to={[X, y2]} start={cReach} dur={18} bob={8}>
          <Pop at={cOnce} s={1.0} k="soft"><Idle amp={2}><Person pose={f >= cTitle ? "raise" : "stand"} cloth={T.l3} glow={f >= cTitle ? T.l2 : undefined} /></Idle></Pop>
        </Mover>
        {items.map((it, i) => (
          <Pop key={i} at={it.at} x={790} y={470 + i * 200} s={1} k="pop" dy={40}>
            <rect x={-220} y={-80} width={440} height={160} rx={30} fill={T.card} stroke={it.c} strokeWidth={6} />
            <g transform="translate(-130 6)"><Idle amp={3} phase={i}>{it.icon}</Idle></g>
            <text x={50} y={18} textAnchor="middle" fontFamily={FONT.display} fontSize={54} fill={T.navy}>{it.t}</text>
          </Pop>
        ))}
        {f >= cFame && f < cFame + 12 && <rect x={0} y={0} width={1080} height={1920} fill="#FFFFFF" opacity={0.35 * (1 - (f - cFame) / 12)} />}
        <Sparkles x={X} y={y2 - 120} at={cTitle} n={8} r={150} c={T.l2} />
      </Stage>
      <Kin y={258} x={640} w={820} segs={[{ t: "LEVEL 2", at: cSecond, big: true, c: T.l2 }, { t: "status needs", at: cStat }]} size={92} small={52} />
      <Chip x={X} y={1262} at={cWhen} text="LEVEL 1 MET" bg={T.good} fg="#fff" border={T.good} size={30} />
    </>
  );
};

// 62.85 – 72.7 s : dogs mark territory, fight to lead the pack → status doesn't separate us
export const SceneH: React.FC = () => {
  const f = useF();
  const cBut = cue("But"), cToo = cue("too"), cTerr = cue("territory", 64.9), cScent = cue("scent"), cFight = cue("fight"), cLead = cue("leader"), cThat = cue("That", 68.3), cChase = cue("chasing"), cNot = cue("doesn't", 70);
  const terr = lin(f, cTerr, cTerr + 18);
  const shake = f >= cFight && f < cLead ? Math.sin(f * 1.7) * 6 : 0;
  const cmp = f >= cThat;
  return (
    <>
      <Stage>
        <Ground at={0} />
        {/* territory boundary */}
        {terr > 0 && <ellipse cx={420} cy={GROUND} rx={360} ry={74} fill="rgba(124,58,237,0.06)" stroke={T.purple} strokeWidth={6} strokeDasharray="22 16" strokeDashoffset={-f * 2} opacity={terr} />}
        <Pop at={0} x={170} y={GROUND} s={1.1} k="soft"><Post /></Pop>
        {/* scent waves */}
        {f >= cScent && [0, 1, 2].map((i) => {
          const t = ((f - cScent + i * 14) % 42) / 42;
          return <path key={i} d={`M ${190 + i * 26} ${GROUND - 40 - t * 260} q 18 -22 0 -44 q -18 -22 0 -44`} stroke={T.purple} strokeWidth={7} fill="none" strokeLinecap="round" opacity={(1 - t) * 0.85} />;
        })}
        <g transform={`translate(${shake} 0)`}>
          <Pop at={0} x={460} y={GROUND} s={1.3} k="soft"><Idle amp={2.5}><Dog pose={f >= cTerr && f < cFight ? "sniff" : "stand"} /></Idle></Pop>
        </g>
        <Mover from={[1250, GROUND]} to={[780, GROUND]} start={cFight - 6} dur={14} bob={6}>
          <g transform={`translate(${-shake} 0)`}><Idle amp={2} phase={1}><Dog body={T.dog2} dark="#6E6E6E" collar={T.pink} flip scale={0.85} /></Idle></g>
        </Mover>
        <Mover from={[1400, GROUND]} to={[960, GROUND]} start={cFight - 2} dur={14} bob={6}>
          <Idle amp={2} phase={2}><Dog body={T.dog3} dark="#3A2C22" collar={T.sky} flip scale={0.75} /></Idle>
        </Mover>
        <Pop at={cLead} out={cThat - 4} x={600} y={GROUND - 395} s={0.95} k="slam"><Idle amp={4} speed={3}><Crown /></Idle></Pop>
        {f < cThat && <Sparkles x={600} y={GROUND - 400} at={cLead} n={8} r={110} />}
        {/* comparison card: human crown = dog crown */}
        {cmp && (
          <g opacity={lin(f, cThat, cThat + 10)}>
            <rect x={90} y={300} width={900} height={420} rx={36} fill={T.card} stroke={T.l2} strokeWidth={6} />
          </g>
        )}
        <Pop at={cThat + 2} x={300} y={680} s={1.0} k="pop"><Idle amp={2}><Person cloth={T.l3} pose="raise" /></Idle></Pop>
        <Pop at={cThat + 6} x={300} y={420} s={0.6} k="slam"><Crown /></Pop>
        <Pop at={cChase} x={540} y={520} s={1} k="slam"><Equals c={T.l2} /></Pop>
        <Pop at={cThat + 4} x={760} y={680} s={0.72} k="pop"><Idle amp={2} phase={1}><Dog flip /></Idle></Pop>
        <Pop at={cThat + 8} x={690} y={470} s={0.55} k="slam"><Crown /></Pop>
      </Stage>
      <Kin y={262} out={cThat - 6} segs={[{ t: "but dogs do this", at: cBut }, { t: "TOO", at: cToo, big: true, c: T.bad, mark: true }]} size={110} small={56} />
      <Chip x={420} y={1272} at={cTerr} out={cThat} text="MARKS TERRITORY" bg={T.purple} fg="#fff" border={T.purple} size={30} />
      <Chip x={600} y={GROUND - 480} at={cLead + 4} out={cThat - 4} text="PACK LEADER" bg={T.gold} fg={T.navy} border={T.navy} size={30} />
      <Chip x={540} y={346} at={cChase} text="FAME & STATUS" bg={T.l2} fg="#fff" border={T.l2} size={32} />
      <Stamp x={540} y={790} at={cNot} text="NO DIFFERENCE" c={T.bad} size={62} />
    </>
  );
};
