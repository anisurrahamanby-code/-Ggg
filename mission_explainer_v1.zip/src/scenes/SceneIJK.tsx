import React from "react";
import { T, FONT } from "../theme";
import { GROUND } from "../config";
import { cue, at } from "../cue";
import { Idle, Mover, Pop, Ring, clamp01, lin, rnd, sp, useF, vis, INOUT } from "../anim";
import { Chip, Ground, Kin, Stage, Sparkles, TopLight } from "../components/Base";
import { Dog, Person } from "../art/Characters";
import { Ladder, rungY } from "../art/Ladder";
import { Arch, Body, Coin, Cross, Eye, Footprint, Lamp, Moon, Star8, Tree } from "../art/Props";

// 72.7 – 77.3 s : where is the real difference? → third level: MISSION
export const SceneI: React.FC = () => {
  const f = useF();
  const cSo = cue("So", 72.8), cReal = cue("real", 73.5), cThird = cue("third", 75.5), cLevel = cue("level", 75.8), cMis = at("mission", 76.5);
  const H = 720, X = 360;
  const y2 = rungY(GROUND, H, 1), y3 = rungY(GROUND, H, 2);
  const lit3 = lin(f, cThird, cThird + 12);
  return (
    <>
      <Stage>
        <TopLight at={cThird} x={X} w={520} y2={y3 + 60} c={T.gold} />
        <Ground at={0} />
        <Ladder x={X} ground={GROUND} h={H} w={260} at={0} rungAt={[0, 2, 4]} lit={f >= cThird ? [2] : [1]} glow3={lit3} locked={f < cThird ? [2] : []} lockAt={-20} />
        <Mover from={[X, y2]} to={[X, y3]} start={cLevel} dur={18} bob={8}>
          <Pop at={0} s={0.98} k="soft"><Idle amp={2}><Person pose={f >= cMis ? "raise" : "stand"} cloth={T.l3} mood={f >= cMis ? "smile" : "open"} glow={f >= cMis ? T.gold : undefined} /></Idle></Pop>
        </Mover>
        <Pop at={0} x={850} y={GROUND} s={0.95} k="soft"><Idle amp={2}><Dog pose="sit" flip dim={lit3 * 0.6} /></Idle></Pop>
        <Pop at={cReal} out={cThird - 4} x={820} y={780} s={1} k="slam">
          <text textAnchor="middle" fontFamily={FONT.display} fontSize={260} fill={T.purple} stroke={T.line} strokeWidth={7} paintOrder="stroke">?</text>
        </Pop>
        {f >= cMis && <Ring x={X} y={y3 - 100} r={150} color={T.gold} start={cMis} period={40} width={7} />}
        <Sparkles x={X} y={y3 - 120} at={cMis} n={14} r={230} />
      </Stage>
      <Kin x={800} w={520} y={300} out={cThird - 6} segs={[{ t: "so where is the", at: cSo }, { t: "REAL", at: cReal, big: true, c: T.bad }, { t: "DIFFERENCE?", at: cReal + 6, big: true }]} size={86} small={46} />
      <Kin x={800} w={520} y={330} segs={[{ t: "the third level", at: cThird }, { t: "MISSION", at: cMis, big: true, c: T.l3, mark: true }]} size={120} small={50} />
    </>
  );
};

// 77.3 – 85.6 s : what will I leave behind? not from the body, no pay, keeps you awake at night
export const SceneJ: React.FC = () => {
  const f = useF();
  const cWhat = cue("What", 77.4), cLeave = cue("leave"), cWorld = cue("world", 78.9), cThis = cue("This", 79.4), cBody = cue("body", 80.5), cNo = cue("no", 81.9), cPays = cue("pays"), cYet = cue("Yet"), cAwake = cue("awake"), cNight = cue("night", 85);
  const walkS = cWhat, walkD = 66;
  const night = lin(f, cYet, cYet + 20);
  const grow = lin(f, cLeave, cLeave + 36, INOUT);
  const px = 170 + (760 - 170) * lin(f, walkS, walkS + walkD, INOUT);
  const cards = [
    { x: 200, at: cue("doesn't", 79.8), t: "NOT FROM", t2: "THE BODY", c: T.l1, icon: <g><Body s={1.25} /><g transform="translate(34 28) scale(0.5)"><Cross /></g></g> },
    { x: 540, at: cNo, t: "NO ONE", t2: "PAYS YOU", c: T.gold, icon: <g><Coin s={0.95} /><g transform="translate(34 28) scale(0.5)"><Cross /></g></g> },
    { x: 880, at: cue("keeps", 84), t: "AWAKE", t2: "AT NIGHT", c: T.l2, icon: <g><g transform="translate(-26 -4)"><Moon s={0.7} /></g><g transform="translate(26 18)"><Eye s={0.6} /></g></g> },
  ];
  return (
    <>
      <Stage>
        {/* night tint */}
        <rect x={0} y={0} width={1080} height={1920} fill={T.night} opacity={night * 0.2} />
        <Ground at={0} />
        {/* stars + moon at night */}
        {night > 0 && (
          <g opacity={night}>
            {Array.from({ length: 12 }).map((_, i) => <circle key={i} cx={80 + rnd(i) * 920} cy={600 + rnd(i + 4) * 300} r={3 + rnd(i + 8) * 4} fill={T.gold} opacity={0.5 + 0.5 * Math.sin(f / 8 + i)} />)}
            <g transform="translate(940 690)"><Moon s={1.1} /></g>
          </g>
        )}
        {/* tree grows where he passed */}
        <Pop at={cLeave} x={230} y={GROUND} s={1.4} k="soft"><Tree grow={grow} /></Pop>
        {/* glowing footprints behind */}
        {Array.from({ length: 8 }).map((_, i) => {
          const fx = 250 + i * 66;
          if (px < fx + 30) return null;
          return <g key={i} transform={`translate(${fx} ${GROUND + 26 + (i % 2) * 18}) rotate(90)`} opacity={0.85}><Footprint s={0.9} c={T.l3} /></g>;
        })}
        {/* walking person */}
        <g transform={`translate(${px} ${GROUND})`}>
          <Idle amp={f < walkS + walkD ? 0 : 2}>
            <g transform={`translate(0 ${f >= walkS && f < walkS + walkD ? -Math.abs(Math.sin(f / 3.2)) * 8 : 0})`}>
              <Person pose={f < walkS + walkD ? "walk" : "stand"} cloth={T.l3} scale={1.45} mood={f >= cAwake ? "open" : "smile"} />
            </g>
          </Idle>
        </g>
        <Pop at={cYet} x={930} y={GROUND} s={1.1} k="pop"><Lamp on={lin(f, cAwake, cAwake + 6)} /></Pop>
        {/* small globe-dot: "in this world" */}
        <Pop at={cWorld} out={cThis} x={540} y={760} s={1} k="pop"><circle r={50} fill={T.sky} stroke={T.line} strokeWidth={5} /><path d="M -30 -20 Q 0 -40 20 -10 Q 0 10 -20 0 Z M 10 20 Q 30 10 36 30 Q 20 44 6 34 Z" fill={T.good} /></Pop>
        {cards.map((c, i) => (
          <Pop key={i} at={c.at} x={c.x} y={470} s={1} k="pop">
            <rect x={-150} y={-160} width={300} height={320} rx={32} fill={T.card} stroke={c.c} strokeWidth={7} />
            <g transform="translate(0 -50)">{c.icon}</g>
            <text y={74} textAnchor="middle" fontFamily={FONT.display} fontSize={44} fill={T.navy}>{c.t}</text>
            <text y={122} textAnchor="middle" fontFamily={FONT.display} fontSize={44} fill={c.c === T.gold ? T.l1 : c.c}>{c.t2}</text>
          </Pop>
        ))}
      </Stage>
      <Kin y={300} out={cThis - 6} segs={[{ t: "what will I", at: cWhat, font: "serif" }, { t: "LEAVE BEHIND", at: cLeave, big: true, c: T.l3, mark: true }, { t: "in this world?", at: cWorld - 4, font: "serif" }]} size={104} small={58} />
    </>
  );
};

// 85.6 – 92.2 s : mission of a true Muslim — rewards continue even after death
export const SceneK: React.FC = () => {
  const f = useF();
  const cNow = cue("Now"), cMis = cue("mission", 86.7), cTrue = cue("true"), cIt = cue("It", 88.7), cRew = cue("rewards"), cCont = cue("continue"), cAfter = cue("after", 91.3), cDeath = at("death");
  const arch = lin(f, cNow, cNow + 30, INOUT);
  const life = lin(f, cIt, cIt + 20, INOUT);
  const walk = lin(f, cIt + 6, cDeath - 6, INOUT);
  const BY = 1030, X0 = 150, XE = 560, X1 = 930;
  return (
    <>
      <Stage>
        {/* geometric motif, faint */}
        {[[150, 420], [930, 420], [150, 1220], [930, 1220]].map(([x, y], i) => (
          <g key={i} transform={`translate(${x} ${y}) rotate(${f * 0.2})`}><Star8 r={46} c={T.gold} sw={4} o={0.35 * arch} /></g>
        ))}
        <g transform="translate(540 1280)"><Arch w={820} h={1030} c={T.gold} sw={9} draw={arch} /></g>
        <g transform="translate(540 1280)" opacity={0.25 * arch}><Arch w={780} h={990} c={T.l3} sw={3} draw={arch} /></g>
        {/* life bar */}
        <rect x={X0} y={BY - 16} width={X1 - X0} height={32} rx={16} fill="#E7E2D6" opacity={life} />
        <rect x={X0} y={BY - 16} width={(XE - X0) * life} height={32} rx={16} fill={T.l3} stroke={T.line} strokeWidth={4} />
        {/* end of life marker */}
        <Pop at={cAfter - 4} x={XE} y={BY} s={1} k="soft">
          <line x1={0} y1={-120} x2={0} y2={80} stroke={T.muted} strokeWidth={6} strokeDasharray="12 10" />
        </Pop>
        {/* rewards keep flowing past the line */}
        {f >= cRew && Array.from({ length: 14 }).map((_, i) => {
          const period = 70;
          const t = ((f - cRew + i * (period / 14)) % period) / period;
          const x = X0 + 40 + t * (X1 - X0 + 20);
          const y = BY - 70 - Math.sin(t * Math.PI * 3 + i) * 18;
          const s = 7 + (i % 3) * 3;
          const o = clamp01((f - cRew) / 10) * clamp01((X1 + 20 - x) / 60);
          return <path key={i} d={`M ${x} ${y - s} L ${x + s * 0.3} ${y - s * 0.3} L ${x + s} ${y} L ${x + s * 0.3} ${y + s * 0.3} L ${x} ${y + s} L ${x - s * 0.3} ${y + s * 0.3} L ${x - s} ${y} L ${x - s * 0.3} ${y - s * 0.3} Z`} fill={T.gold} opacity={o} />;
        })}
        {/* gold arrow continuing beyond */}
        <Pop at={cCont} x={X1 + 10} y={BY} s={1} k="pop"><path d="M -30 -26 L 10 0 L -30 26" fill="none" stroke={T.gold} strokeWidth={12} strokeLinecap="round" strokeLinejoin="round" /></Pop>
        {/* small person walking along life */}
        <g transform={`translate(${X0 + 30 + (XE - X0 - 60) * walk} ${BY - 18})`} opacity={life}>
          <Person pose={walk > 0 && walk < 1 ? "walk" : "stand"} scale={0.62} cloth={T.l3} />
        </g>
      </Stage>
      <Kin y={400} segs={[{ t: "the mission of a", at: cMis }, { t: "TRUE MUSLIM", at: cTrue, big: true, c: T.l3, mark: true }]} size={100} small={54} />
      <Chip x={(X0 + XE) / 2} y={BY + 80} at={cIt} text="THIS LIFE" bg={T.l3} fg="#fff" border={T.l3} size={30} />
      <Chip x={740} y={BY - 170} at={cCont} text="REWARDS CONTINUE" bg={T.gold} fg={T.navy} border={T.navy} size={32} />
      <Chip x={XE + 10} y={BY + 150} at={cAfter} text="AFTER DEATH" bg={T.card} fg={T.ink} border={T.muted} size={30} />
    </>
  );
};
