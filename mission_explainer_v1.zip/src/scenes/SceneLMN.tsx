import React from "react";
import { T, FONT } from "../theme";
import { GROUND } from "../config";
import { cue, at } from "../cue";
import { WORDS } from "../data/words";
import { Idle, Mover, Pop, Ring, clamp01, lin, rnd, sp, useF, vis, INOUT } from "../anim";
import { Chip, Ground, Kin, Stage, Stamp, Sparkles } from "../components/Base";
import { Person } from "../art/Characters";
import { Arch, Board, Book, Check, GradCap, Laptop, Mat, Page, Star8, Well } from "../art/Props";

// 92.2 – 103.1 s : the hadith — all deeds end except three
export const SceneL: React.FC = () => {
  const f = useF();
  const cPro = cue("Prophet"), cWhen = cue("When", 94.5), cAll = cue("all", 96.4), cEnd = at("end", 97.9), cExc = at("except"), cOn = cue("ongoing"), cBen = cue("beneficial"), cA = cue("a", 102), cChild = cue("child");
  // quote words revealed with the voice
  const qWords = WORDS.filter((w) => w[1] >= 94.55 && w[1] < 98.9);
  const lamps = Array.from({ length: 9 }).map((_, i) => 113 + i * 106.75);
  const keep = [1, 4, 7];
  const cards = [
    { x: 220, at: cOn, t: "ONGOING", t2: "CHARITY", sub: "Sadaqah Jariyah", c: T.l3, icon: <Well s={1.05} /> },
    { x: 540, at: cBen, t: "BENEFICIAL", t2: "KNOWLEDGE", sub: "that others use", c: T.sky, icon: <Book s={1.05} glow /> },
    { x: 860, at: cA, t: "A RIGHTEOUS", t2: "CHILD", sub: "who prays for them", c: T.pink, icon: <g transform="translate(0 70)"><Person pose="dua" scale={0.72} cloth={T.pink} pants={T.l2} mood="calm" /></g> },
  ];
  return (
    <>
      <Stage>
        {[[90, 300], [990, 300]].map(([x, y], i) => <g key={i} transform={`translate(${x} ${y}) rotate(${f * 0.25})`}><Star8 r={40} c={T.gold} sw={4} o={0.4} /></g>)}
        {/* deed lamps */}
        {lamps.map((x, i) => {
          const p = sp(f, cAll + i * 2, "snap");
          if (p <= 0.01) return null;
          const isKeep = keep.includes(i);
          const off = isKeep ? 0 : lin(f, cEnd + (i % 5) * 2, cEnd + (i % 5) * 2 + 8);
          const y = 842;
          const k = keep.indexOf(i);
          const moved = isKeep ? lin(f, cards[k].at - 6, cards[k].at + 6) : 0;
          const glow = isKeep && f >= cExc ? 0.5 + 0.25 * Math.sin(f / 6 + i) : 0.3 * (1 - off);
          return (
            <g key={i} transform={`translate(${x} ${y}) scale(${(0.6 + 0.4 * p) * (1 + 0.15 * (isKeep && f >= cExc ? 1 : 0))})`} opacity={1 - moved * 0.9}>
              <circle r={44} fill={T.gold} opacity={glow} />
              <circle r={24} fill={off > 0.5 ? "#C9C4B8" : T.gold} stroke={T.line} strokeWidth={4} />
              <rect x={-11} y={22} width={22} height={14} rx={3} fill={T.muted} stroke={T.line} strokeWidth={3} />
            </g>
          );
        })}
        {f >= cExc && f < cOn && keep.map((i) => <Ring key={i} x={lamps[i]} y={842} r={40} color={T.gold} start={cExc} />)}
        {/* three cards */}
        {cards.map((c, i) => (
          <Pop key={i} at={c.at} x={c.x} y={1104} s={1} k="soft" dy={50}>
            <rect x={-150} y={-180} width={300} height={360} rx={32} fill={T.card} stroke={c.c} strokeWidth={7} />
            <circle cx={-118} cy={-150} r={24} fill={c.c} stroke={T.line} strokeWidth={4} />
            <text x={-118} y={-140} textAnchor="middle" fontFamily={FONT.display} fontSize={30} fill="#fff">{i + 1}</text>
            <g transform="translate(0 -60)">{c.icon}</g>
            <text y={70} textAnchor="middle" fontFamily={FONT.display} fontSize={38} fill={T.navy}>{c.t}</text>
            <text y={112} textAnchor="middle" fontFamily={FONT.display} fontSize={38} fill={c.c}>{c.t2}</text>
            <text y={150} textAnchor="middle" fontFamily={FONT.serif} fontStyle="italic" fontSize={25} fill={T.ink}>{c.sub}</text>
          </Pop>
        ))}
        <Sparkles x={540} y={1104} at={cChild} n={12} r={420} />
      </Stage>
      {/* prophet chip (text only, never drawn) */}
      <Chip x={540} y={296} at={cPro} text="Prophet Muhammad (peace be upon him) said:" bg={T.card} fg={T.navy} border={T.gold} size={32} />
      {/* quote card */}
      <div style={{ position: "absolute", left: 540, top: 360, width: 940, transform: `translateX(-50%) translateY(${(1 - sp(f, cWhen - 6, "soft")) * 40}px)`, opacity: clamp01(sp(f, cWhen - 6, "soft") * 3) }}>
        <div style={{ boxSizing: "border-box", padding: "30px 46px 26px", borderRadius: 32, background: T.card, border: `4px solid ${T.gold}`, boxShadow: "0 18px 40px rgba(27,42,74,0.18)", position: "relative" }}>
          <svg width={70} height={56} style={{ position: "absolute", left: 18, top: -24 }}><path d="M 8 50 Q 2 20 26 6 L 30 14 Q 18 24 20 34 L 30 34 L 30 50 Z M 40 50 Q 34 20 58 6 L 62 14 Q 50 24 52 34 L 62 34 L 62 50 Z" fill={T.l3} /></svg>
          <div style={{ fontFamily: FONT.serif, fontSize: 50, lineHeight: 1.22, color: T.ink, display: "flex", flexWrap: "wrap", columnGap: 13 }}>
            {qWords.map((w, i) => {
              const fr = Math.round(w[1] * 30) - 2;
              const p = lin(f, fr, fr + 6);
              const clean = w[0].replace(/^"/, "");
              const hl = /except|three/.test(clean);
              const hp = hl ? lin(f, cExc, cExc + 10) : 0;
              return (
                <span key={i} style={{ opacity: 0.12 + 0.88 * p, fontWeight: hl ? 400 : 400, color: hl && p > 0.5 ? T.bad : T.ink,
                  backgroundImage: `linear-gradient(transparent 60%, ${T.highlight} 60%, ${T.highlight} 92%, transparent 92%)`, backgroundSize: `${hp * 100}% 100%`, backgroundRepeat: "no-repeat" }}>{clean}</span>
              );
            })}
          </div>
          <div style={{ marginTop: 14, textAlign: "right", fontFamily: FONT.semi, fontWeight: 700, fontSize: 28, color: T.l3, opacity: lin(f, cExc + 8, cExc + 20) }}>— Sahih Muslim 1631</div>
        </div>
      </div>
    </>
  );
};

// 103.1 – 111.7 s : many forms — imam (habit of prayer), teacher (next generation of scholars)
export const SceneM: React.FC = () => {
  const f = useF();
  const cThis = cue("This", 103.2), cMany = cue("many"), cImam = cue("imam"), cHelps = cue("helps"), cHabit = cue("habit"), cPrayer = cue("prayer"), cTeach = cue("teacher"), cRaises = cue("raises"), cGen = cue("generation"), cSch = cue("scholars");
  const G2 = 1150;
  const grow = lin(f, cGen, cGen + 18, INOUT);
  return (
    <>
      <Stage>
        <Ground y={G2} at={0} />
        <line x1={540} y1={480} x2={540} y2={G2 - 10} stroke={T.navy} strokeWidth={4} strokeDasharray="12 12" opacity={0.25 * lin(f, cImam, cImam + 10)} />
        {/* IMAM side */}
        <Pop at={cImam} x={140} y={G2} s={1.25} k="pop"><Idle amp={2}><Person cap cloth={T.l3} pants={T.navy} pose="point" mood="smile" /></Idle></Pop>
        {[0, 1, 2].map((i) => (
          <g key={i}>
            <Pop at={cHelps + i * 4} x={300 + i * 80} y={G2} s={1} k="snap"><Mat c={[T.l3, T.l1, T.l2][i]} /></Pop>
            <Pop at={cue("people", 106.6) + i * 5} x={300 + i * 80} y={G2 - 10} s={0.62} k="pop"><Idle amp={1.5} phase={i}><Person cap={i !== 1} cloth={[T.sky, T.purple, T.l1][i]} pose="stand" mood="calm" /></Idle></Pop>
          </g>
        ))}
        {/* habit streak */}
        {Array.from({ length: 5 }).map((_, i) => (
          <Pop key={i} at={cHabit + i * 3} x={110 + i * 80} y={720} s={0.95} k="slam"><Check s={1} c={T.l3} /></Pop>
        ))}
        {/* TEACHER side */}
        <Pop at={cTeach - 6} x={830} y={980} s={0.78} k="pop"><Board /></Pop>
        <Pop at={cTeach} x={630} y={G2} s={1.15} k="pop"><Idle amp={2}><Person cloth={T.l1} pants={T.navy} tie={T.bad} pose="point" /></Idle></Pop>
        {[0, 1, 2].map((i) => {
          const s = 0.5 + 0.22 * grow;
          return (
            <g key={i}>
              <Pop at={cRaises + i * 3} x={770 + i * 95} y={G2} s={s} k="pop"><Idle amp={2} phase={i}><Person cloth={[T.sky, T.pink, T.purple][i]} pose={grow >= 1 ? "raise" : "stand"} mood="smile" /></Idle></Pop>
              <Pop at={cSch - 4 + i * 3} x={770 + i * 95} y={G2 - 215 * s - 12} s={0.75 * (s / 0.72)} k="slam"><GradCap /></Pop>
            </g>
          );
        })}
      </Stage>
      <Kin y={270} segs={[{ t: "it can take", at: cThis }, { t: "MANY FORMS", at: cMany, big: true, c: T.purple, mark: true }]} size={100} small={54} />
      <Chip x={280} y={480} at={cImam} text="IMAM" bg={T.l3} fg="#fff" border={T.l3} size={40} />
      <Chip x={280} y={800} at={cPrayer} text="HABIT OF PRAYER" bg={T.card} fg={T.l3} border={T.l3} size={30} />
      <Chip x={800} y={480} at={cTeach} text="TEACHER" bg={T.l1} fg="#fff" border={T.l1} size={40} />
      <Chip x={850} y={1240} at={cSch} text="NEXT GEN OF SCHOLARS" bg={T.card} fg={T.navy} border={T.l1} size={28} />
    </>
  );
};

// 111.7 – 117.1 s : writing or videos to call people toward Allah → all of these are missions
export const SceneN: React.FC = () => {
  const f = useF();
  const cSome = cue("Someone", 111.9), cWrit = cue("writing"), cVid = cue("videos"), cCall = cue("call", 113.7), cToward = cue("toward", 114.2), cAll = cue("All", 115.6), cMis = at("missions");
  const people = Array.from({ length: 8 }).map((_, i) => {
    const a = (-165 + i * (150 / 7)) * (Math.PI / 180);
    return { x: 540 + Math.cos(a) * 410, y: 900 + Math.sin(a) * 400 };
  });
  const fadeMain = 1 - lin(f, cAll - 4, cAll + 6);
  return (
    <>
      <Stage>
        <g opacity={fadeMain}>
          <Pop at={cSome} x={540} y={1040} s={1.6} k="pop"><Idle amp={2}><Laptop play={f >= cVid} /></Idle></Pop>
          <Pop at={cWrit} x={190} y={1010} s={1.05} k="pop" rot={-6}><Page /></Pop>
          <Pop at={cVid} x={890} y={1000} s={0.85} k="pop" rot={5}>
            <rect x={-110} y={-80} width={220} height={150} rx={18} fill={T.bad} stroke={T.line} strokeWidth={5} />
            <path d="M -22 -32 L 32 -4 L -22 24 Z" fill="#fff" />
          </Pop>
          {f >= cCall && [0, 1, 2].map((i) => <Ring key={i} x={540} y={900} r={120} color={T.l3} start={cCall + i * 12} period={36} width={6} />)}
          {people.map((p, i) => {
            const lit = f >= cToward + i * 2;
            return (
              <Pop key={i} at={cCall + i * 2} x={p.x} y={p.y} s={0.58} k="pop">
                <Idle amp={2} phase={i}><Person cloth={lit ? [T.l3, T.l1, T.l2, T.pink, T.sky, T.purple, T.good, T.l1][i] : "#C9C4B8"} mood={lit ? "smile" : "calm"} glow={lit ? T.gold : undefined} pose={lit ? "raise" : "stand"} /></Idle>
              </Pop>
            );
          })}
        </g>
        {/* all of these are missions */}
        {[
          { x: 240, icon: <g transform="translate(0 70)"><Person cap cloth={T.l3} scale={0.6} /></g>, c: T.l3 },
          { x: 540, icon: <g transform="translate(0 60)"><Board s={0.48} /></g>, c: T.l1 },
          { x: 840, icon: <g transform="translate(0 40)"><Laptop s={0.62} /></g>, c: T.bad },
        ].map((b, i) => (
          <Pop key={i} at={cAll + i * 4} x={b.x} y={820} s={1} k="pop">
            <circle r={130} fill={T.card} stroke={b.c} strokeWidth={8} />
            {b.icon}
          </Pop>
        ))}
        {[0, 1, 2].map((i) => <Pop key={i} at={cMis + i * 3} x={[240, 540, 840][i] + 92} y={720} s={1.1} k="slam"><Check s={1.2} /></Pop>)}
      </Stage>
      <Kin y={270} out={cAll - 6} segs={[{ t: "WRITING", at: cWrit, big: true, c: T.l3 }, { t: "or", at: cue("or", 112.9) }, { t: "VIDEOS", at: cVid, big: true, c: T.bad }]} size={100} small={56} />
      <Chip x={540} y={1250} at={cToward} out={cAll - 4} text="CALLING PEOPLE TOWARD ALLAH" bg={T.l3} fg="#fff" border={T.l3} size={32} />
      <Kin y={300} segs={[{ t: "all of these are", at: cAll }]} size={60} small={56} />
      <Stamp x={540} y={1080} at={cMis} text="MISSIONS" c={T.l3} size={86} rot={-4} />
    </>
  );
};
