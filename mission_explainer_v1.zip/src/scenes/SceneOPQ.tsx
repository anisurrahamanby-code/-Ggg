import React from "react";
import { T, FONT } from "../theme";
import { GROUND } from "../config";
import { cue, at } from "../cue";
import { Idle, Mover, Pop, Ring, clamp01, lin, sp, useF, vis, INOUT } from "../anim";
import { Chip, Ground, Kin, Stage, Stamp, Sparkles, TopLight } from "../components/Base";
import { Dog, Person } from "../art/Characters";
import { Ladder, rungY } from "../art/Ladder";
import { Book, Crown, Globe, Heart, House, Star } from "../art/Props";

// 117.1 – 126.8 s : define your own mission — know / good at / love → together
export const SceneO: React.FC = () => {
  const f = useF();
  const cDef = cue("define"), cOwn = cue("own"), cW1 = cue("What", 119.3), cW2 = cue("What", 120.3), cW3 = cue("What", 121.5), cBring = cue("Bring"), cTog = cue("together"), cDecide = cue("decide"), cCall = cue("call", 125.4), cAllah = cue("Allah", 126);
  const m = lin(f, cBring, cTog + 6, INOUT);
  const circles = [
    { at: cW1, from: [290, 720], to: [440, 760], t: "WHAT YOU KNOW", c: T.sky, icon: <Book s={0.8} /> },
    { at: cW2, from: [790, 720], to: [640, 760], t: "WHAT YOU'RE GOOD AT", c: T.l1, icon: <Star s={0.75} c={T.l1} /> },
    { at: cW3, from: [540, 1060], to: [540, 935], t: "WHAT YOU LOVE", c: T.pink, icon: <Heart s={0.8} /> },
  ];
  const center = sp(f, cTog + 4, "slam");
  return (
    <>
      <Stage>
        {f >= cDecide && Array.from({ length: 12 }).map((_, i) => {
          const a = (i / 12) * Math.PI * 2 + f / 90;
          const r1 = 150, r2 = 330 + Math.sin(f / 10 + i) * 20;
          return <line key={i} x1={540 + Math.cos(a) * r1} y1={830 + Math.sin(a) * r1} x2={540 + Math.cos(a) * r2} y2={830 + Math.sin(a) * r2} stroke={T.gold} strokeWidth={10} strokeLinecap="round" opacity={0.45 * lin(f, cDecide, cDecide + 12)} />;
        })}
        {circles.map((c, i) => {
          const x = c.from[0] + (c.to[0] - c.from[0]) * m, y = c.from[1] + (c.to[1] - c.from[1]) * m;
          return (
            <Pop key={i} at={c.at} x={x} y={y} s={1} k="pop" dy={30}>
              <circle r={190} fill={c.c} opacity={0.22} />
              <circle r={190} fill="none" stroke={c.c} strokeWidth={7} />
              <g opacity={1 - m} transform="translate(0 -30)">{c.icon}</g>
              <text y={76 - m * 6} textAnchor="middle" fontFamily={FONT.display} fontSize={36 - m * 6} fill={T.navy} opacity={1 - m}>{c.t}</text>
              <text x={[-120, 120, 0][i]} y={[-160, -160, 235][i]} textAnchor="middle" fontFamily={FONT.display} fontSize={46} fill={c.c} stroke={T.card} strokeWidth={8} paintOrder="stroke" opacity={m}>{["KNOW", "GOOD AT", "LOVE"][i]}</text>
            </Pop>
          );
        })}
        {center > 0.01 && (
          <g transform={`translate(540 830) scale(${center})`}>
            <circle r={96} fill={T.gold} opacity={0.35} />
            <Star s={1.15} c={T.gold} />
          </g>
        )}
        <Sparkles x={540} y={830} at={cTog + 4} n={12} r={220} />
      </Stage>
      <Kin y={270} segs={[{ t: "define your", at: cDef }, { t: "OWN MISSION", at: cOwn, big: true, c: T.l3, mark: true }]} size={104} small={56} />
      <Chip x={540} y={1000} at={cTog + 8} out={cDecide + 6} text="YOUR MISSION" bg={T.navy} fg={T.highlight} border={T.gold} size={40} />
      <Chip x={540} y={1236} at={cCall} text="CALL PEOPLE TOWARD ALLAH" bg={T.l3} fg="#fff" border={T.l3} size={34} />
    </>
  );
};

// 126.8 – 130.8 s : positive change to your community and the world
export const SceneP: React.FC = () => {
  const f = useF();
  const cBring = cue("bring", 127.6), cPos = cue("positive"), cCom = cue("community"), cWorld = at("world", 130);
  const houses = [{ x: 130, s: 1.0 }, { x: 290, s: 1.2 }, { x: 790, s: 1.2 }, { x: 950, s: 1.0 }, { x: 210, s: 0.75, y: -150 }, { x: 870, s: 0.75, y: -150 }];
  const zoom = lin(f, cWorld - 6, cWorld + 14, INOUT);
  return (
    <>
      <Stage>
        <g transform={`translate(540 ${GROUND}) scale(${1 - 0.25 * zoom}) translate(-540 ${-GROUND})`}>
          <Ground at={0} />
          {houses.map((h, i) => {
            const lit = f >= cCom + i * 3;
            const lp = lin(f, cPos + i * 2, cPos + i * 2 + 14);
            return (
              <g key={i}>
                {lp > 0 && <line x1={540} y1={GROUND - 200} x2={540 + (h.x - 540) * lp} y2={GROUND - 200 + ((h.y ?? 0) - 40 + 200) * lp} stroke={T.gold} strokeWidth={5} strokeDasharray="12 10" />}
                <Pop at={cBring + i * 2} x={h.x} y={GROUND + (h.y ?? 0)} s={h.s} k="pop"><House lit={lit} c={[T.l1, T.l2, T.l3, T.pink, T.purple, T.sky][i]} /></Pop>
                {lit && <Ring x={h.x} y={GROUND + (h.y ?? 0) - 50 * h.s} r={40} color={T.gold} start={cCom + i * 3} />}
              </g>
            );
          })}
          <Pop at={0} x={540} y={GROUND} s={1.4} k="soft"><Idle amp={2}><Person pose="raise" cloth={T.l3} glow={T.gold} /></Idle></Pop>
        </g>
        <Pop at={cWorld - 4} x={540} y={640} s={1.75} k="soft">
          <circle r={120} fill={T.gold} opacity={0.3} />
          <Globe />
        </Pop>
        <Sparkles x={540} y={640} at={cWorld} n={10} r={220} />
      </Stage>
      <Kin y={270} segs={[{ t: "POSITIVE", at: cPos, big: true, c: T.good }, { t: "CHANGE", at: cue("change", 128.3), big: true, mark: true }]} size={100} />
      <Chip x={540} y={1262} at={cCom} text="YOUR COMMUNITY" bg={T.l1} fg="#fff" border={T.l1} size={34} />
      <Chip x={540} y={862} at={cWorld} text="AND THE WORLD" bg={T.sky} fg="#fff" border={T.sky} size={36} />
    </>
  );
};

// 130.8 – end : callback — physical & status: no difference; mission belongs only to humans
export const SceneQ: React.FC = () => {
  const f = useF();
  const cBack = cue("back", 131.3), cDog = cue("dog", 132.7), cPhys = cue("physical", 134), cStat = cue("status", 135), cNo = at("no", 135.9),
    cOnly = cue("only", 138.7), cMis = at("mission", 140), cMis2 = cue("Mission", 140.9), cBel = cue("belongs"), cHum = at("humans");
  const H = 640, X = 540;
  const y1 = rungY(GROUND, H, 0), y2 = rungY(GROUND, H, 1), y3 = rungY(GROUND, H, 2);
  // person path: ground → rung1 → rung2 → rung3
  const py = f < cPhys ? GROUND : f < cStat ? GROUND + (y1 - GROUND) * lin(f, cPhys, cPhys + 14, INOUT) : f < cMis - 6 ? y1 + (y2 - y1) * lin(f, cStat, cStat + 14, INOUT) : y2 + (y3 - y2) * lin(f, cMis - 6, cMis + 12, INOUT);
  const px = f < cPhys ? 300 : 300 + (440 - 300) * lin(f, cPhys, cPhys + 14, INOUT);
  const dy = f < cPhys ? GROUND : f < cStat ? GROUND + (y1 - GROUND) * lin(f, cPhys + 3, cPhys + 17, INOUT) : y1 + (y2 - y1) * lin(f, cStat + 3, cStat + 17, INOUT);
  const dx = f < cPhys ? 830 : 830 + (650 - 830) * lin(f, cPhys + 3, cPhys + 17, INOUT);
  const fin = lin(f, cMis, cMis + 16);
  const moving = (a: number) => f >= a && f < a + 14;
  const climbing = moving(cPhys) || moving(cStat) || moving(cMis - 6);
  return (
    <>
      <Stage>
        <TopLight at={cMis} x={X} w={560} y2={y3 + 80} />
        <Ground at={0} />
        <Ladder x={X} ground={GROUND} h={H} w={360} at={cBack - 10} rungAt={[cBack, cBack + 4, cBack + 8]} lit={f >= cMis ? [2] : f >= cStat ? [1] : f >= cPhys ? [0] : []} glow3={fin} dimUpper={0} />
        {f >= cMis && <Ring x={X} y={y3 - 100} r={170} color={T.gold} start={cMis} period={42} width={7} />}
        <g transform={`translate(${dx} ${dy - (moving(cPhys + 3) || moving(cStat + 3) ? Math.abs(Math.sin(f / 3)) * 10 : 0)})`}>
          <Pop at={0} s={0.58} k="soft"><Idle amp={2} phase={1}><Dog flip pose="stand" dim={fin * 0.6} /></Idle></Pop>
          <Pop at={cStat + 14} out={cMis} x={-56} y={-168} s={0.42} k="slam"><Crown /></Pop>
        </g>
        <g transform={`translate(${f >= cMis - 6 ? px + (X - px) * lin(f, cMis - 6, cMis + 12, INOUT) : px} ${py - (climbing ? Math.abs(Math.sin(f / 3)) * 10 : 0)})`}>
          <Pop at={0} s={0.8} k="soft"><Idle amp={2}><Person pose={f >= cMis ? "raise" : "stand"} cloth={T.l3} glow={f >= cMis ? T.gold : undefined} /></Idle></Pop>
          <Pop at={cStat + 12} out={cMis} x={0} y={-205} s={0.42} k="slam"><Crown /></Pop>
        </g>
        {f >= cPhys && f < cMis - 8 && (
          <Pop at={cPhys + 14} out={cMis - 10} x={548} y={(f < cStat ? y1 : y2) - 90} s={0.5} k="slam">
            <rect x={-50} y={-38} width={100} height={24} rx={12} fill={T.l2} stroke={T.line} strokeWidth={5} />
            <rect x={-50} y={12} width={100} height={24} rx={12} fill={T.l2} stroke={T.line} strokeWidth={5} />
          </Pop>
        )}
        <Sparkles x={X} y={y3 - 110} at={cMis} n={16} r={260} />
      </Stage>
      <Kin y={262} out={cOnly - 6} segs={[{ t: "back to the", at: cBack }, { t: "DOG", at: cDog, big: true, c: T.l1, mark: true }]} size={104} small={56} />
      <Stamp x={540} y={480} at={cNo} out={cOnly - 8} text="NO DIFFERENCE" c={T.bad} size={60} />
      <Kin y={250} segs={[{ t: "the only real difference", at: cOnly }, { t: "MISSION", at: cMis, big: true, c: T.l3, mark: true }]} size={118} small={50} />
      <Chip x={540} y={1262} at={cBel} text="BELONGS ONLY TO HUMANS" bg={T.navy} fg={T.highlight} border={T.gold} size={40} />
    </>
  );
};
