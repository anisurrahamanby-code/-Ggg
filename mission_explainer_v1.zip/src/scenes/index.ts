import React from "react";
import { sec } from "../cue";
import { DURATION } from "../config";
import { SceneA } from "./SceneA";
import { SceneB, SceneC } from "./SceneBC";
import { SceneD, SceneE } from "./SceneDE";
import { SceneF, SceneG, SceneH } from "./SceneFGH";
import { SceneI, SceneJ, SceneK } from "./SceneIJK";
import { SceneL, SceneM, SceneN } from "./SceneLMN";
import { SceneO, SceneP, SceneQ } from "./SceneOPQ";

export type SceneDef = { name: string; start: number; end: number; C: React.FC; enter?: "fade" | "up" | "zoom" | "right"; noExit?: boolean };
const S = (name: string, a: number, b: number, C: React.FC, enter: SceneDef["enter"] = "up"): SceneDef => ({ name, start: sec(a), end: sec(b), C, enter });
export const SCENES: SceneDef[] = [
  S("A dog-life", 0, 10.9, SceneA, "zoom"),
  S("B ladder", 10.9, 15.3, SceneB),
  S("C maslow-1943", 15.3, 23.0, SceneC, "right"),
  S("D three-levels", 23.0, 33.1, SceneD),
  S("E level1-hunger", 33.1, 47.2, SceneE, "right"),
  S("F dog-same", 47.2, 53.2, SceneF),
  S("G level2-status", 53.2, 62.85, SceneG, "right"),
  S("H dogs-status", 62.85, 72.7, SceneH),
  S("I mission-reveal", 72.7, 77.3, SceneI, "zoom"),
  S("J leave-behind", 77.3, 85.6, SceneJ),
  S("K true-muslim", 85.6, 92.2, SceneK, "fade"),
  S("L hadith", 92.2, 103.1, SceneL, "fade"),
  S("M many-forms", 103.1, 111.7, SceneM),
  S("N writing-videos", 111.7, 117.1, SceneN, "right"),
  S("O define-mission", 117.1, 126.8, SceneO),
  S("P community-world", 126.8, 130.8, SceneP, "zoom"),
  { name: "Q callback-final", start: sec(130.8), end: DURATION, C: SceneQ, enter: "fade", noExit: true },
];
