import React from "react";
import { Audio, Sequence, interpolate, staticFile } from "remotion";

// SFX from the user's ZIP only (renamed ASCII). gain table ≈ voice −14…−18 dB (files peak near 0 dBFS; paper files are quiet)
export const SFX_GAIN: Record<string, number> = {
  whoosh1: 0.16, whoosh2: 0.16, whoosh3: 0.13, pop: 0.14, bubble_pop: 0.16, riser: 0.16, impact_boom: 0.2, suspense_boom: 0.13,
  thud: 0.13, correct: 0.12, ding: 0.16, ting: 0.16, sparkle: 0.12, wrong: 0.11, paper: 0.5, paper_slide: 0.9, page_flip: 0.7,
  shutter: 0.3, camera_flash: 0.12, marker: 0.2, typing: 0.09, light_switch: 0.14, flashback: 0.15, click: 0.18, scratch: 0.1, item: 0.11,
};
export type SfxCue = { at: number; s: string; len?: number; gain?: number; rate?: number };

export const SfxTrack: React.FC<{ cues: SfxCue[] }> = ({ cues }) => (
  <>
    {cues.map((c, i) => {
      const len = c.len ?? 45;
      const g = (c.gain ?? 1) * (SFX_GAIN[c.s] ?? 0.15);
      return (
        <Sequence key={i} from={Math.max(0, c.at)} durationInFrames={len} name={`sfx ${c.s}`}>
          <Audio src={staticFile(`sfx/${c.s}.mp3`)} playbackRate={c.rate ?? 1}
            volume={(fr) => g * interpolate(fr, [0, len - 10, len], [1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
        </Sequence>
      );
    })}
  </>
);
