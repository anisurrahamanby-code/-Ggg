import { SfxCue } from "./sfx";
import { at, cue, sec } from "./cue";

// Every cue sits on the frame where the visual event happens (word-start based).
export const SFX_CUES: SfxCue[] = [
  // A — dog's life → you → real difference?
  { at: 0, s: "whoosh3", len: 34 },
  { at: cue("eats") - 2, s: "pop", len: 20 },
  { at: cue("sleeps"), s: "bubble_pop", len: 24, gain: 0.8 },
  { at: cue("guards"), s: "pop", len: 20 },
  { at: cue("mate"), s: "ting", len: 40 },
  { at: cue("You", 4.9) - 6, s: "whoosh1", len: 30 },
  { at: cue("exact"), s: "correct", len: 30, gain: 0.8 },
  { at: cue("what", 7), s: "suspense_boom", len: 60 },
  // B — ladder
  { at: cue("ladder", 11.5) - 14, s: "riser", len: 30, gain: 0.8 },
  { at: cue("ladder", 11.5), s: "thud", len: 40 },
  { at: cue("human", 14), s: "marker", len: 18 },
  // C — Maslow 1943
  { at: sec(15.3), s: "whoosh2", len: 30 },
  { at: cue("In", 15.4) + 6, s: "shutter", len: 16 },
  { at: at("1943"), s: "pop", len: 20 },
  { at: cue("Abraham"), s: "paper_slide", len: 22 },
  { at: cue("Maslow's"), s: "pop", len: 20 },
  { at: cue("this", 21.8), s: "whoosh3", len: 26, gain: 0.7 },
  // D — three levels
  { at: cue("physical", 25), s: "pop", len: 18 },
  { at: cue("status", 26), s: "pop", len: 18 },
  { at: cue("mission", 27.5), s: "ding", len: 50, gain: 0.8 },
  { at: cue("until", 29), s: "click", len: 20 },
  { at: cue("met", 30), s: "correct", len: 30, gain: 0.7 },
  // E — level 1
  { at: sec(33.1), s: "whoosh1", len: 28 },
  { at: cue("eaten"), s: "pop", len: 18 },
  { at: at("two", 37) - 16, s: "paper", len: 26 },
  { at: cue("Nobel") - 4, s: "bubble_pop", len: 24 },
  { at: at("Not", 40.5), s: "wrong", len: 40, gain: 0.8 },
  { at: cue("hunger", 42), s: "pop", len: 18 },
  { at: cue("thirst", 42.5), s: "pop", len: 18 },
  { at: cue("sleep", 43.5), s: "pop", len: 18 },
  { at: cue("satisfied", 44), s: "correct", len: 30 },
  { at: cue("silent", 46), s: "thud", len: 30, gain: 0.6 },
  // F — dog same
  { at: cue("dog", 47.5) - 8, s: "whoosh2", len: 28 },
  { at: cue("exact", 48), s: "pop", len: 20 },
  { at: at("no", 50.7), s: "impact_boom", len: 50, gain: 0.8 },
  // G — level 2
  { at: cue("reach"), s: "whoosh3", len: 26 },
  { at: cue("second"), s: "pop", len: 18 },
  { at: cue("title"), s: "item", len: 26 },
  { at: cue("fame", 60), s: "camera_flash", len: 30 },
  { at: cue("power"), s: "pop", len: 20 },
  { at: cue("respect"), s: "ting", len: 40 },
  // H — dogs status
  { at: cue("too"), s: "pop", len: 20 },
  { at: cue("territory", 64.9), s: "marker", len: 20 },
  { at: cue("fight") - 6, s: "whoosh1", len: 26 },
  { at: cue("leader"), s: "ding", len: 50, gain: 0.8 },
  { at: cue("That", 68.3), s: "paper_slide", len: 22 },
  { at: cue("doesn't", 70), s: "thud", len: 40 },
  // I — mission reveal
  { at: cue("real", 73.5), s: "suspense_boom", len: 60, gain: 0.8 },
  { at: cue("third") - 20, s: "riser", len: 40 },
  { at: at("mission", 76.5), s: "impact_boom", len: 60 },
  { at: at("mission", 76.5) + 4, s: "sparkle", len: 60, gain: 0.7 },
  // J — leave behind
  { at: cue("leave"), s: "sparkle", len: 50, gain: 0.6 },
  { at: cue("doesn't", 79.8), s: "pop", len: 18 },
  { at: cue("no", 81.9), s: "pop", len: 18 },
  { at: cue("Yet"), s: "whoosh2", len: 26, gain: 0.7 },
  { at: cue("awake"), s: "light_switch", len: 16 },
  // K — true Muslim (soft)
  { at: cue("Now"), s: "whoosh3", len: 30, gain: 0.7 },
  { at: cue("true"), s: "ding", len: 50, gain: 0.6 },
  { at: cue("rewards"), s: "sparkle", len: 70, gain: 0.6 },
  // L — hadith (soft)
  { at: cue("When", 94.5) - 6, s: "page_flip", len: 40 },
  { at: at("end", 97.9), s: "light_switch", len: 14, gain: 0.7 },
  { at: at("except"), s: "ting", len: 40, gain: 0.7 },
  { at: cue("ongoing"), s: "pop", len: 18, gain: 0.8 },
  { at: cue("beneficial"), s: "pop", len: 18, gain: 0.8 },
  { at: cue("a", 102), s: "pop", len: 18, gain: 0.8 },
  { at: cue("child"), s: "sparkle", len: 60, gain: 0.5 },
  // M — many forms
  { at: cue("many"), s: "whoosh1", len: 26 },
  { at: cue("imam"), s: "pop", len: 18 },
  { at: cue("habit"), s: "correct", len: 30, gain: 0.6 },
  { at: cue("teacher"), s: "pop", len: 18 },
  { at: cue("scholars"), s: "ting", len: 40, gain: 0.7 },
  // N — writing / videos
  { at: cue("writing"), s: "typing", len: 28 },
  { at: cue("videos"), s: "click", len: 20 },
  { at: cue("call", 113.7), s: "whoosh3", len: 30 },
  { at: at("missions"), s: "thud", len: 40 },
  // O — define your mission
  { at: cue("own"), s: "marker", len: 18 },
  { at: cue("What", 119.3), s: "pop", len: 18 },
  { at: cue("What", 120.3), s: "pop", len: 18 },
  { at: cue("What", 121.5), s: "pop", len: 18 },
  { at: cue("together") + 4, s: "impact_boom", len: 50, gain: 0.7 },
  // P — community & world
  { at: cue("community"), s: "ting", len: 40, gain: 0.7 },
  { at: at("world", 130) - 4, s: "whoosh2", len: 28 },
  // Q — callback & final
  { at: cue("back", 131.3) - 6, s: "flashback", len: 50 },
  { at: cue("physical", 134), s: "pop", len: 18 },
  { at: cue("status", 135), s: "pop", len: 18 },
  { at: at("no", 135.9), s: "thud", len: 40 },
  { at: at("mission", 140) - 18, s: "riser", len: 22, gain: 0.8 },
  { at: at("mission", 140), s: "impact_boom", len: 60 },
  { at: at("mission", 140) + 4, s: "sparkle", len: 80, gain: 0.6 },
  { at: cue("belongs"), s: "pop", len: 20 },
];
