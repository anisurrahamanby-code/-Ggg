// Role-based colours. User asked: off-white graph-grid paper + a mix of all colours.
export const T = {
  paper: "#F5F1E8",
  card: "#FFFDF7",
  ink: "#1F2937",
  navy: "#1B2A4A",
  navyLite: "#2B3F68",
  highlight: "#FCD34D",
  good: "#16A34A",
  bad: "#C81E1E",
  muted: "#8B8F98",
  grid: "rgba(27,42,74,0.07)",
  gridBold: "rgba(27,42,74,0.13)",
  // level colours (one world, same meaning everywhere)
  l1: "#E07A1F", // physical (amber)
  l2: "#4F46E5", // status (indigo)
  l3: "#0F9D8A", // mission (teal)
  gold: "#E9B949",
  pink: "#DB2777",
  sky: "#0EA5E9",
  purple: "#7C3AED",
  // art palette
  skin: "#E9B48C",
  skin2: "#C98B62",
  hair: "#2A1E1A",
  dog: "#C98A4B",
  dogDark: "#8E5A2E",
  dog2: "#9C9C9C",
  dog3: "#5B4636",
  line: "#1B2A4A",
  wood: "#B9824F",
  white: "#FFFFFF",
  night: "#22305A",
};
export const FONT = {
  display: "'AnekC', 'Hind Siliguri', sans-serif",
  sans: "'Hind', 'Hind Siliguri', sans-serif",
  semi: "'AnekSC', 'Hind Siliguri', sans-serif",
  serif: "'Tiro', Georgia, serif",
};
