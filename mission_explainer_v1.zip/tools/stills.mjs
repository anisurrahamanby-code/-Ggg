// usage: node tools/stills.mjs <projectDir> <outDir> <frame,frame,...> [scale]
// optional: set BROWSER=<path to chrome> to use a local browser; otherwise Remotion uses its own.
import { bundle } from "@remotion/bundler";
import { renderStill, selectComposition } from "@remotion/renderer";
import path from "node:path";
const browserExecutable = process.env.BROWSER || null;
const [proj, outDir, frames, scale = "0.5"] = process.argv.slice(2);
const serveUrl = await bundle({ entryPoint: path.join(proj, "src/index.ts"), publicDir: path.join(proj, "public") });
const comp = await selectComposition({ serveUrl, id: "Main", browserExecutable });
for (const fr of frames.split(",").map(Number)) {
  await renderStill({ composition: comp, serveUrl, output: path.join(outDir, `f${String(fr).padStart(5, "0")}.jpg`), frame: fr, scale: Number(scale), imageFormat: "jpeg", browserExecutable, chromiumOptions: { gl: "swangle" } });
  process.stdout.write(fr + " ");
}
console.log("done");
