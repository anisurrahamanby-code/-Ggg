import re,json,sys
srt=open(sys.argv[1],encoding='utf-8-sig').read().replace('\r','')
cues=[]
for b in re.split(r'\n{2,}',srt.strip()):
    L=[l for l in b.split('\n') if l.strip()]
    i=[k for k,l in enumerate(L) if '-->' in l][0]
    m=re.findall(r'(\d+):(\d+):(\d+)[,.](\d+)',L[i])
    t=lambda x:int(x[0])*3600+int(x[1])*60+int(x[2])+int(x[3])/1000
    cues.append(dict(s=t(m[0]),e=t(m[1]),text=' '.join(L[i+1:]).strip()))
sil=[];cur=None
for l in open(sys.argv[2]):
    k,v=l.split(': ');v=float(v)
    if 'start' in k: cur=v
    else: sil.append((cur if cur is not None else 0.0,v));cur=None
if cur is not None: sil.append((cur,1e9))
def syl(w):
    w=re.sub(r'[^a-z0-9]','',w.lower())
    if re.match(r'^\d+$',w): return len(w)*1.5
    n=len(re.findall(r'[aeiouy]+',w)); 
    if w.endswith('e') and n>1: n-=1
    return max(1,n)
words=[]
for c in cues:
    # speech segments in cue
    segs=[[c['s'],c['e']]]
    for a,b in sil:
        new=[]
        for s,e in segs:
            if b<=s or a>=e: new.append([s,e]); continue
            if a>s: new.append([s,a])
            if b<e: new.append([b,e])
        segs=new
    segs=[x for x in segs if x[1]-x[0]>0.06]
    ws=c['text'].split()
    phrases=[];p=[]
    for w in ws:
        p.append(w)
        if re.search(r'[,.?!:;"]$',w): phrases.append(p);p=[]
    if p: phrases.append(p)
    def dist(wl,s,e):
        tot=sum(syl(w)+0.6 for w in wl);t=s;out=[]
        for w in wl:
            d=(e-s)*(syl(w)+0.6)/tot; out.append(dict(w=w,s=round(t,3),e=round(t+d,3)));t+=d
        return out
    if len(phrases)==len(segs):
        for ph,(s,e) in zip(phrases,segs): words+=dist(ph,s,e)
    else:
        # distribute across concatenated speech time
        tot=sum(e-s for s,e in segs);W=[(w,syl(w)+0.6) for w in ws];wt=sum(x[1] for x in W)
        acc=0
        def mapt(x):
            for s,e in segs:
                if x<=e-s+1e-9: return s+x
                x-=(e-s)
            return segs[-1][1]
        for w,k in W:
            a=acc/wt*tot;acc+=k;b=acc/wt*tot
            words.append(dict(w=w,s=round(mapt(a),3),e=round(mapt(b-1e-6),3)))
    c['mapped']=len(phrases)==len(segs)
json.dump(dict(cues=cues,words=words),open(sys.argv[3],'w'),indent=1)
print(sum(c['mapped'] for c in cues),'/',len(cues),'cues phrase-mapped;',len(words),'words')
dur=sum(w['e']-w['s'] for w in words)/len(words);print('avg word',round(dur,3),'wpm',round(len(words)/(cues[-1]['e']-cues[0]['s'])*60))
